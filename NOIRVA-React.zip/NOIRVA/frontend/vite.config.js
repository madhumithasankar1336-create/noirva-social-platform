import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Port 5500 must match CLIENT_URL in backend/.env (CORS + cookies depend on it).
export default defineConfig({
  plugins: [react()],
  server: { port: 5500, strictPort: true, host: 'localhost' },
});
