import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api } from '../api/client.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Restore the session from the HttpOnly cookie on first load.
  useEffect(() => {
    let active = true;
    api.get('/auth/me')
      .then((d) => active && setUser(d.user))
      .catch(() => active && setUser(null))
      .finally(() => active && setLoading(false));

    // Any protected API call that returns 401 ends the session in the UI.
    const onUnauthorized = () => setUser(null);
    window.addEventListener('noirva:unauthorized', onUnauthorized);
    return () => {
      active = false;
      window.removeEventListener('noirva:unauthorized', onUnauthorized);
    };
  }, []);

  const login = useCallback(async (identifier, password) => {
    const d = await api.post('/auth/login', { identifier, password });
    setUser(d.user);
    return d.user;
  }, []);

  const register = useCallback(async (formData) => {
    const d = await api.upload('/auth/register', 'POST', formData);
    setUser(d.user);
    return d.user;
  }, []);

  const logout = useCallback(async () => {
    try {
      await api.post('/auth/logout');
    } catch {
      // Clear local state even if the request fails.
    }
    setUser(null);
  }, []);

  const value = useMemo(
    () => ({ user, loading, login, register, logout, updateUser: setUser }),
    [user, loading, login, register, logout]
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}
