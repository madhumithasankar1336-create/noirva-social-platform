import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api } from '../api/client.js';
import { useAuth } from './AuthContext.jsx';

const NotificationContext = createContext(null);

export function NotificationProvider({ children }) {
  const { user } = useAuth();
  const [unread, setUnread] = useState(0);

  const refresh = useCallback(async () => {
    try {
      const d = await api.get('/notifications?limit=1');
      setUnread(d.unreadCount);
    } catch {
      // Badge is best-effort.
    }
  }, []);

  useEffect(() => {
    if (!user) {
      setUnread(0);
      return undefined;
    }
    refresh();
    const id = setInterval(refresh, 60000);
    return () => clearInterval(id);
  }, [user, refresh]);

  const value = useMemo(() => ({ unread, setUnread, refresh }), [unread, refresh]);
  return <NotificationContext.Provider value={value}>{children}</NotificationContext.Provider>;
}

export function useNotifications() {
  return useContext(NotificationContext);
}
