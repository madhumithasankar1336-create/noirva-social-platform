import { EmptyState } from '../components/States.jsx';

export default function NotFound() {
  return (
    <div className="auth-body">
      <EmptyState icon="fa-compass" title="Page not found" text="This page does not exist in NOIRVA." actionTo="/" actionLabel="Back to home" />
    </div>
  );
}
