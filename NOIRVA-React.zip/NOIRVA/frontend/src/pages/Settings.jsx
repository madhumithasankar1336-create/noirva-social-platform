import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api, apiRequest } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import Field from '../components/Field.jsx';
import Modal from '../components/Modal.jsx';
import PasswordField from '../components/PasswordField.jsx';

const EMPTY_PW = { currentPassword: '', newPassword: '', confirmPassword: '' };

export default function Settings() {
  const { logout, updateUser } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();

  const [pw, setPw] = useState(EMPTY_PW);
  const [pwErrors, setPwErrors] = useState({});
  const [pwBusy, setPwBusy] = useState(false);

  const [delOpen, setDelOpen] = useState(false);
  const [del, setDel] = useState({ confirmText: '', password: '' });
  const [delErrors, setDelErrors] = useState({});
  const [delBusy, setDelBusy] = useState(false);

  const setPwField = (e) => setPw((p) => ({ ...p, [e.target.name]: e.target.value }));
  const setDelField = (e) => setDel((d) => ({ ...d, [e.target.name]: e.target.value }));

  async function changePassword(e) {
    e.preventDefault();
    const errors = {};
    if (!pw.currentPassword) errors.currentPassword = 'Enter your current password';
    if (pw.newPassword.length < 8) errors.newPassword = 'Use at least 8 characters';
    if (pw.newPassword !== pw.confirmPassword) errors.confirmPassword = 'Passwords do not match';
    setPwErrors(errors);
    if (Object.keys(errors).length) return;

    setPwBusy(true);
    try {
      const d = await api.post('/auth/change-password', pw);
      setPw(EMPTY_PW);
      toast(d.message);
    } catch (err) {
      setPwErrors(err.errors || {});
      toast(err.message, 'error');
    } finally {
      setPwBusy(false);
    }
  }

  async function handleLogout() {
    await logout();
    navigate('/login', { replace: true });
  }

  async function deleteAccount(e) {
    e.preventDefault();
    const errors = {};
    if (del.confirmText.trim() !== 'DELETE') errors.confirmText = 'Type DELETE to confirm';
    if (!del.password) errors.password = 'Enter your password';
    setDelErrors(errors);
    if (Object.keys(errors).length) return;

    setDelBusy(true);
    try {
      // silentAuth: a wrong password returns 401 here, and must not log the user out.
      await apiRequest('/users/me', { method: 'DELETE', body: { password: del.password }, silentAuth: true });
      toast('Your account has been deleted');
      updateUser(null);
      navigate('/login', { replace: true });
    } catch (err) {
      setDelErrors(err.errors || { password: err.message });
    } finally {
      setDelBusy(false);
    }
  }

  return (
    <>
      <div className="page-title"><h1>Settings</h1></div>
      <div className="settings-stack">
        <section className="card settings-card">
          <h2>Profile</h2>
          <p className="muted">Update your name, bio, location, website, and images.</p>
          <Link className="btn btn-outline btn-sm" to="/profile?edit=1">Edit profile</Link>
        </section>

        <section className="card settings-card">
          <h2>Change password</h2>
          <p className="muted small">Changing your password signs out your other sessions.</p>
          <form onSubmit={changePassword} noValidate>
            <PasswordField label="Current password" name="currentPassword" value={pw.currentPassword}
              onChange={setPwField} error={pwErrors.currentPassword} autoComplete="current-password" />
            <PasswordField label="New password" name="newPassword" value={pw.newPassword}
              onChange={setPwField} error={pwErrors.newPassword} autoComplete="new-password" />
            <PasswordField label="Confirm new password" name="confirmPassword" value={pw.confirmPassword}
              onChange={setPwField} error={pwErrors.confirmPassword} autoComplete="new-password" />
            <button className="btn btn-gold" type="submit" disabled={pwBusy}>
              {pwBusy ? 'Updating…' : 'Update password'}
            </button>
          </form>
        </section>

        <section className="card settings-card">
          <h2>Session</h2>
          <p className="muted">Sign out of NOIRVA on this device.</p>
          <button className="btn btn-outline btn-sm" type="button" onClick={handleLogout}>
            <i className="fa-solid fa-right-from-bracket" aria-hidden="true" /> Logout
          </button>
        </section>

        <section className="card settings-card danger-zone">
          <h2>Delete account</h2>
          <p className="muted">
            Permanently removes your profile, posts, comments, likes, follows, and notifications. This cannot be undone.
          </p>
          <button className="btn btn-danger btn-sm" type="button" onClick={() => { setDel({ confirmText: '', password: '' }); setDelErrors({}); setDelOpen(true); }}>
            Delete my account
          </button>
        </section>
      </div>

      {delOpen && (
        <Modal title="Delete your account?" onClose={() => setDelOpen(false)}>
          <form onSubmit={deleteAccount} noValidate>
            <p className="muted">Type <strong>DELETE</strong> and enter your password to confirm.</p>
            <Field label="Type DELETE" name="confirmText" autoComplete="off" value={del.confirmText}
              onChange={setDelField} error={delErrors.confirmText} />
            <PasswordField label="Password" name="password" value={del.password}
              onChange={setDelField} error={delErrors.password} autoComplete="current-password" />
            <div className="dialog-actions">
              <button type="button" className="btn btn-outline" onClick={() => setDelOpen(false)}>Cancel</button>
              <button type="submit" className="btn btn-danger" disabled={delBusy}>
                {delBusy ? 'Deleting…' : 'Delete account'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </>
  );
}
