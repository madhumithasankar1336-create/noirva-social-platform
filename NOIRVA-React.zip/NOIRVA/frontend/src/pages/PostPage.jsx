import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api } from '../api/client.js';
import PostCard from '../components/PostCard.jsx';
import { EmptyState, ErrorState, Skeletons } from '../components/States.jsx';

export default function PostPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [state, setState] = useState({ status: 'loading', post: null, error: '' });
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setState({ status: 'loading', post: null, error: '' });
    api.get(`/posts/${id}`)
      .then((d) => { if (!cancelled) setState({ status: 'ok', post: d.post, error: '' }); })
      .catch((err) => {
        if (cancelled) return;
        const notFound = err.status === 404 || err.status === 400;
        setState({ status: notFound ? 'notfound' : 'error', post: null, error: err.message });
      });
    return () => { cancelled = true; };
  }, [id, reloadKey]);

  if (state.status === 'loading') return <Skeletons count={1} />;
  if (state.status === 'notfound') {
    return (
      <EmptyState icon="fa-file-circle-question" title="This post is unavailable"
        text="It may have been deleted, or the link is incomplete." actionTo="/" actionLabel="Back to home" />
    );
  }
  if (state.status === 'error') {
    return <ErrorState message={state.error} onRetry={() => setReloadKey((k) => k + 1)} />;
  }
  return <PostCard post={state.post} initialCommentsOpen onDelete={() => navigate('/', { replace: true })} />;
}
