import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { api, mediaUrl } from '../api/client.js';
import Avatar from '../components/Avatar.jsx';
import FollowButton from '../components/FollowButton.jsx';
import PostCard from '../components/PostCard.jsx';
import { EmptyState, ErrorState, Skeletons } from '../components/States.jsx';

// Discovery sections built only from real data.
function Discover() {
  const [data, setData] = useState(null);

  useEffect(() => {
    let cancelled = false;
    Promise.allSettled([
      api.get('/users/suggestions'),
      api.get('/search/trending'),
      api.get('/posts?tab=popular&limit=3'),
      api.get('/posts?tab=latest&limit=3'),
      api.get('/posts?tab=latest&media=1&limit=12'),
    ]).then(([s, t, p, r, m]) => {
      if (cancelled) return;
      setData({
        users: s.value?.users || [],
        tags: t.value?.tags || [],
        popular: p.value?.posts || [],
        recent: r.value?.posts || [],
        media: m.value?.posts || [],
      });
    });
    return () => {
      cancelled = true;
    };
  }, []);

  if (!data) return <Skeletons count={3} />;

  return (
    <>
      <h2 className="section-title">Suggested people</h2>
      {data.users.length ? (
        <div className="user-list">
          {data.users.map((u) => (
            <div className="user-row" key={u.id}>
              <Avatar user={u} size="sm" />
              <Link className="info" to={`/profile/${u.username}`}>
                <strong>{u.name}</strong>
                <span className="muted small">@{u.username}</span>
              </Link>
              <FollowButton userId={u.id} />
            </div>
          ))}
        </div>
      ) : (
        <p className="muted">No suggestions right now.</p>
      )}

      <h2 className="section-title">Trending hashtags (last 7 days)</h2>
      {data.tags.length ? (
        <div className="tag-list">
          {data.tags.map((t) => (
            <Link key={t.tag} to={`/explore?tag=${encodeURIComponent(t.tag)}`}>
              <span className="hashtag">#{t.tag}</span>
              <span className="muted small">{t.count} post{t.count === 1 ? '' : 's'}</span>
            </Link>
          ))}
        </div>
      ) : (
        <p className="muted">No trending hashtags yet. Posts with #hashtags will appear here.</p>
      )}

      <h2 className="section-title">Popular posts</h2>
      {data.popular.length ? (
        <div className="feed">
          {data.popular.map((p) => <PostCard key={p.id} post={p} />)}
        </div>
      ) : (
        <p className="muted">Popular posts will appear once people start liking them.</p>
      )}

      <h2 className="section-title">Recently published</h2>
      {data.recent.length ? (
        <div className="feed">
          {data.recent.map((p) => <PostCard key={p.id} post={p} />)}
        </div>
      ) : (
        <p className="muted">No posts yet.</p>
      )}

      <h2 className="section-title">Image discovery</h2>
      {data.media.length ? (
        <div className="media-grid">
          {data.media.map((p) => (
            <Link key={p.id} to={`/post/${p.id}`} aria-label="Open post">
              <img src={mediaUrl(p.imageUrl)} alt={p.content ? p.content.slice(0, 80) : 'Post image'} loading="lazy" />
            </Link>
          ))}
        </div>
      ) : (
        <p className="muted">Image posts will appear here.</p>
      )}
    </>
  );
}

export default function Explore() {
  const [params] = useSearchParams();
  const [q, setQ] = useState(() => (params.get('tag') ? `#${params.get('tag')}` : ''));
  const [debounced, setDebounced] = useState(q);
  const [results, setResults] = useState(null);
  const [searching, setSearching] = useState(false);
  const [error, setError] = useState('');

  // Following a hashtag link on the same page updates the search box.
  useEffect(() => {
    const tag = params.get('tag');
    if (tag) setQ(`#${tag}`);
  }, [params]);

  // Debounce so we do not call the API on every keystroke.
  useEffect(() => {
    const id = setTimeout(() => setDebounced(q.trim()), 350);
    return () => clearTimeout(id);
  }, [q]);

  // Run search; the abort controller cancels stale requests when the query changes.
  useEffect(() => {
    if (!debounced) {
      setResults(null);
      setError('');
      return undefined;
    }
    if (debounced.length > 100) return undefined;

    const controller = new AbortController();
    const { signal } = controller;
    const enc = encodeURIComponent(debounced);
    setSearching(true);
    setError('');

    Promise.all([
      api.get(`/search/users?q=${enc}`, { signal }),
      api.get(`/search/hashtags?q=${enc}`, { signal }),
      api.get(`/search/posts?q=${enc}&limit=10`, { signal }),
    ])
      .then(([users, tags, posts]) => setResults({ users: users.users, tags: tags.tags, posts: posts.posts }))
      .catch((err) => {
        if (err.name !== 'AbortError') setError(err.message);
      })
      .finally(() => {
        if (!signal.aborted) setSearching(false);
      });

    return () => controller.abort();
  }, [debounced]);

  const removePost = (id) =>
    setResults((r) => (r ? { ...r, posts: r.posts.filter((p) => p.id !== id) } : r));

  return (
    <>
      <div className="page-title"><h1>Explore</h1></div>
      <div className="search-bar">
        <i className="fa-solid fa-magnifying-glass" aria-hidden="true" />
        <label htmlFor="explore-search" className="sr-only">Search people, hashtags, and posts</label>
        <input
          id="explore-search"
          className="input"
          type="search"
          maxLength={100}
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search people, #hashtags, or posts"
          autoComplete="off"
        />
      </div>

      {!debounced && <Discover />}

      {debounced && (
        <>
          {searching && !results && <Skeletons count={2} />}
          {error && <ErrorState message={error} />}
          {results && !error && (() => {
            const none = !results.users.length && !results.tags.length && !results.posts.length;
            if (none) {
              return (
                <EmptyState
                  icon="fa-magnifying-glass"
                  title="No results found"
                  text={`Nothing matched "${debounced}". Try another name, username, or hashtag.`}
                />
              );
            }
            return (
              <>
                {results.users.length > 0 && (
                  <>
                    <h2 className="section-title">People</h2>
                    <div className="user-list">
                      {results.users.map((u) => (
                        <Link key={u.id} className="user-row" to={`/profile/${u.username}`}>
                          <Avatar user={u} size="sm" />
                          <span className="info">
                            <strong>{u.name}</strong>
                            <span className="muted small">@{u.username}</span>
                          </span>
                        </Link>
                      ))}
                    </div>
                  </>
                )}
                {results.tags.length > 0 && (
                  <>
                    <h2 className="section-title">Hashtags</h2>
                    <div className="tag-list">
                      {results.tags.map((t) => (
                        <Link key={t.tag} to={`/explore?tag=${encodeURIComponent(t.tag)}`}>
                          <span className="hashtag">#{t.tag}</span>
                          <span className="muted small">{t.count} post{t.count === 1 ? '' : 's'}</span>
                        </Link>
                      ))}
                    </div>
                  </>
                )}
                {results.posts.length > 0 && (
                  <>
                    <h2 className="section-title">Posts</h2>
                    <div className="feed">
                      {results.posts.map((p) => <PostCard key={p.id} post={p} onDelete={removePost} />)}
                    </div>
                  </>
                )}
              </>
            );
          })()}
        </>
      )}
    </>
  );
}
