import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import Field from '../components/Field.jsx';
import PasswordField from '../components/PasswordField.jsx';

export default function Login() {
  const { login } = useAuth();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    const errs = {};
    if (!identifier.trim()) errs.identifier = 'Enter your email or username';
    if (!password) errs.password = 'Enter your password';
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setFormError('');
    setBusy(true);
    try {
      // On success the auth state changes and GuestRoute redirects to the "next" page.
      await login(identifier.trim(), password);
    } catch (err) {
      setFormError(err.message);
      setErrors(err.errors || {});
      setBusy(false);
    }
  }

  return (
    <div className="auth-body">
      <main className="auth-wrap">
        <section className="card auth-card">
          <div className="auth-brand">
            <img className="auth-logo" src="/assets/logo.svg" alt="" />
            <h1 className="brand-wordmark">NOIRVA</h1>
            <p className="tagline">Your World. Your Circle. Your Noirva.</p>
          </div>
          <form onSubmit={submit} noValidate>
            <Field label="Email or username" name="identifier" autoComplete="username" value={identifier}
              onChange={(e) => setIdentifier(e.target.value)} error={errors.identifier} />
            <PasswordField label="Password" name="password" autoComplete="current-password" value={password}
              onChange={(e) => setPassword(e.target.value)} error={errors.password} />
            {formError && <p className="form-error" role="alert">{formError}</p>}
            <button className="btn btn-gold btn-block" type="submit" disabled={busy}>
              {busy ? 'Signing in…' : 'Sign in'}
            </button>
          </form>
          <p className="muted center auth-footer">New to NOIRVA? <Link to="/register">Create an account</Link></p>
        </section>
      </main>
    </div>
  );
}
