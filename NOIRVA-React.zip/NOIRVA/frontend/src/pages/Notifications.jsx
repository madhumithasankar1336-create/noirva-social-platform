import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client.js';
import { useToast } from '../context/ToastContext.jsx';
import { useNotifications } from '../context/NotificationContext.jsx';
import Avatar from '../components/Avatar.jsx';
import { EmptyState, ErrorState, Skeletons } from '../components/States.jsx';
import { timeAgo } from '../utils/format.js';

const MESSAGES = {
  follow: 'started following you',
  like: 'liked your post',
  comment: 'commented on your post',
};

function targetOf(n) {
  if (n.post) return `/post/${n.post.id}`;
  if (n.sender) return `/profile/${n.sender.username}`;
  return null;
}

export default function Notifications() {
  const toast = useToast();
  const { refresh, setUnread } = useNotifications();

  const [items, setItems] = useState([]);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError('');
    api.get('/notifications?page=1&limit=20')
      .then((d) => {
        if (cancelled) return;
        setItems(d.notifications);
        setPage(1);
        setHasMore(d.hasMore);
      })
      .catch((err) => { if (!cancelled) setError(err.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [reloadKey]);

  async function loadMore() {
    const next = page + 1;
    setLoading(true);
    try {
      const d = await api.get(`/notifications?page=${next}&limit=20`);
      setItems((list) => [...list, ...d.notifications]);
      setPage(next);
      setHasMore(d.hasMore);
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  }

  async function markAll() {
    try {
      await api.patch('/notifications/read-all');
      setItems((list) => list.map((n) => ({ ...n, read: true })));
      setUnread(0);
      toast('All notifications marked as read');
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  async function markOne(n) {
    if (n.read) return;
    try {
      await api.patch(`/notifications/${n.id}/read`);
      setItems((list) => list.map((x) => (x.id === n.id ? { ...x, read: true } : x)));
      refresh();
    } catch {
      // Navigation still works if marking fails.
    }
  }

  return (
    <>
      <div className="page-title">
        <h1>Notifications</h1>
        <button className="btn btn-outline btn-sm" type="button" onClick={markAll}>
          <i className="fa-solid fa-check-double" aria-hidden="true" /> Mark all as read
        </button>
      </div>

      {error && <ErrorState message={error} onRetry={() => setReloadKey((k) => k + 1)} />}

      <section className="notif-list" aria-live="polite">
        {loading && !items.length && <Skeletons count={3} />}
        {items.map((n) => {
          const to = targetOf(n);
          const body = (
            <>
              <Avatar user={n.sender} size="sm" />
              <div className="notif-body">
                <p>
                  <strong>{n.sender ? n.sender.name : 'Someone'}</strong> {MESSAGES[n.type] || 'interacted with you'}
                </p>
                {n.post ? (
                  <p className="muted small">{n.post.snippet ? `“${n.post.snippet}”` : 'Image post'}</p>
                ) : (
                  n.type !== 'follow' && <p className="muted small">This post is no longer available</p>
                )}
                <time className="muted small" dateTime={n.createdAt}>{timeAgo(n.createdAt)}</time>
              </div>
              {!n.read && <span className="dot" aria-label="Unread" />}
            </>
          );
          const className = `notif${n.read ? '' : ' unread'}`;
          return to ? (
            <Link key={n.id} to={to} className={className} onClick={() => markOne(n)}>{body}</Link>
          ) : (
            <div key={n.id} className={className}>{body}</div>
          );
        })}
        {!loading && !error && !items.length && (
          <EmptyState
            icon="fa-bell-slash"
            title="No notifications yet"
            text="When someone follows, likes, or comments on your posts, you will see it here."
            actionTo="/explore"
            actionLabel="Explore NOIRVA"
          />
        )}
      </section>

      {hasMore && (
        <div className="load-more-wrap">
          <button className="btn btn-outline" type="button" disabled={loading} onClick={loadMore}>
            {loading ? 'Loading…' : 'Load more'}
          </button>
        </div>
      )}
    </>
  );
}
