import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { api } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import Avatar from '../components/Avatar.jsx';
import Composer from '../components/Composer.jsx';
import PostCard from '../components/PostCard.jsx';
import { EmptyState, ErrorState, Skeletons } from '../components/States.jsx';

const TABS = [
  ['for-you', 'For You'],
  ['following', 'Following'],
  ['latest', 'Latest'],
];

const EMPTY_COPY = {
  'for-you': ['Nothing here yet', 'Be the first to share something with the community.'],
  following: ['Your following feed is quiet', 'Follow people to see their posts here.'],
  latest: ['No posts yet', 'Publish the first post on NOIRVA.'],
};

function mergeUnique(prev, incoming) {
  const ids = new Set(prev.map((p) => p.id));
  return [...prev, ...incoming.filter((p) => !ids.has(p.id))];
}

export default function Home() {
  const { user } = useAuth();
  const toast = useToast();
  const location = useLocation();

  const [tab, setTab] = useState('for-you');
  const [posts, setPosts] = useState([]);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [reloadKey, setReloadKey] = useState(0);
  const [stories, setStories] = useState([]);

  // Reload the first page whenever the tab changes or the user presses Retry.
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError('');
    setPosts([]);
    setPage(0);
    api.get(`/posts?tab=${tab}&page=1&limit=10`)
      .then((d) => {
        if (cancelled) return;
        setPosts(d.posts);
        setPage(1);
        setHasMore(d.hasMore);
      })
      .catch((err) => {
        if (!cancelled) setError(err.message);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [tab, reloadKey]);

  useEffect(() => {
    api.get('/users/suggestions').then((d) => setStories(d.users)).catch(() => {});
  }, []);

  // "Create Post" in the sidebar links to /#composer: focus the composer.
  useEffect(() => {
    if (location.hash === '#composer') {
      document.getElementById('composer-text')?.focus();
      document.getElementById('composer')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [location.hash]);

  async function loadMore() {
    const next = page + 1;
    setLoading(true);
    try {
      const d = await api.get(`/posts?tab=${tab}&page=${next}&limit=10`);
      setPosts((list) => mergeUnique(list, d.posts));
      setPage(next);
      setHasMore(d.hasMore);
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  }

  const removePost = (id) => setPosts((list) => list.filter((p) => p.id !== id));
  const addPost = (post) => setPosts((list) => [post, ...list.filter((p) => p.id !== post.id)]);

  return (
    <>
      <section className="card welcome">
        <div>
          <p className="eyebrow">NOIRVA</p>
          <h1>Welcome back, {user.name.split(' ')[0]}</h1>
          <p className="muted">Share a moment, discover voices, and stay close to the people you follow.</p>
        </div>
      </section>

      <section className="stories" aria-label="Suggested people">
        <Link className="story" to={`/profile/${user.username}`}>
          <span className="story-ring"><Avatar user={user} /></span>
          <span>You</span>
        </Link>
        {stories.map((u) => (
          <Link key={u.id} className="story" to={`/profile/${u.username}`}>
            <span className="story-ring"><Avatar user={u} /></span>
            <span>{u.name.split(' ')[0]}</span>
          </Link>
        ))}
      </section>

      <Composer onPublished={addPost} />

      <div className="feed-tabs" role="tablist" aria-label="Feed">
        {TABS.map(([id, label]) => (
          <button key={id} className="tab" role="tab" type="button" aria-selected={tab === id} onClick={() => setTab(id)}>
            {label}
          </button>
        ))}
      </div>

      {error && !posts.length && <ErrorState message={error} onRetry={() => setReloadKey((k) => k + 1)} />}

      <section className="feed" aria-live="polite">
        {loading && !posts.length && <Skeletons count={3} />}
        {posts.map((post) => (
          <PostCard key={post.id} post={post} onDelete={removePost} />
        ))}
        {!loading && !error && !posts.length && (
          <EmptyState
            title={EMPTY_COPY[tab][0]}
            text={EMPTY_COPY[tab][1]}
            actionTo={tab === 'following' ? '/explore' : '/#composer'}
            actionLabel={tab === 'following' ? 'Discover people' : 'Create a post'}
          />
        )}
      </section>

      {hasMore && (
        <div className="load-more-wrap">
          <button className="btn btn-outline" type="button" disabled={loading} onClick={loadMore}>
            {loading ? 'Loading…' : 'Load more'}
          </button>
        </div>
      )}
    </>
  );
}
