import { useEffect, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { api } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import Avatar from '../components/Avatar.jsx';
import Field from '../components/Field.jsx';
import FollowButton from '../components/FollowButton.jsx';
import Modal from '../components/Modal.jsx';
import PostCard from '../components/PostCard.jsx';
import SafeImage from '../components/SafeImage.jsx';
import { EmptyState, ErrorState, Skeletons } from '../components/States.jsx';
import { formatDate, validateImageFile } from '../utils/format.js';

function EditProfileModal({ profile, onClose, onSaved }) {
  const toast = useToast();
  const [form, setForm] = useState({
    name: profile.name,
    bio: profile.bio || '',
    location: profile.location || '',
    website: profile.website || '',
  });
  const [files, setFiles] = useState({ profilePicture: null, coverImage: null });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);

  const change = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  function pick(e) {
    const chosen = e.target.files[0];
    if (!chosen) return;
    const problem = validateImageFile(chosen);
    if (problem) {
      toast(problem, 'error');
      e.target.value = '';
      return;
    }
    setFiles((f) => ({ ...f, [e.target.name]: chosen }));
  }

  async function submit(e) {
    e.preventDefault();
    setErrors({});
    setFormError('');
    setBusy(true);
    const fd = new FormData();
    Object.entries(form).forEach(([k, v]) => fd.append(k, v.trim()));
    Object.entries(files).forEach(([k, f]) => {
      if (f) fd.append(k, f);
    });
    try {
      const d = await api.upload('/users/me', 'PUT', fd);
      onSaved(d.user);
    } catch (err) {
      setErrors(err.errors || {});
      setFormError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal title="Edit profile" onClose={onClose}>
      <form onSubmit={submit} noValidate>
        <Field label="Full name" name="name" value={form.name} onChange={change} error={errors.name} maxLength={60} />
        <Field as="textarea" rows={3} label="Bio" name="bio" value={form.bio} onChange={change} error={errors.bio} maxLength={160} />
        <Field label="Location" name="location" value={form.location} onChange={change} error={errors.location} maxLength={80} />
        <Field label="Website" name="website" type="url" value={form.website} onChange={change} error={errors.website} maxLength={200} placeholder="https://" />
        <Field label="Profile picture" name="profilePicture" type="file" accept="image/jpeg,image/png,image/gif,image/webp" onChange={pick} error={errors.profilePicture} />
        <Field label="Cover image" name="coverImage" type="file" accept="image/jpeg,image/png,image/gif,image/webp" onChange={pick} error={errors.coverImage} />
        {formError && <p className="form-error" role="alert">{formError}</p>}
        <div className="dialog-actions">
          <button type="button" className="btn btn-outline" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-gold" disabled={busy}>{busy ? 'Saving…' : 'Save changes'}</button>
        </div>
      </form>
    </Modal>
  );
}

function UserListModal({ username, type, onClose }) {
  const [users, setUsers] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    api.get(`/users/${username}/${type}?limit=50`)
      .then((d) => { if (!cancelled) setUsers(d.users); })
      .catch((err) => { if (!cancelled) setError(err.message); });
    return () => { cancelled = true; };
  }, [username, type]);

  return (
    <Modal title={type === 'followers' ? 'Followers' : 'Following'} onClose={onClose}>
      <div className="list-body">
        {error && <p className="muted">{error}</p>}
        {!users && !error && <p className="muted">Loading…</p>}
        {users && users.length === 0 && (
          <p className="muted center">{type === 'followers' ? 'No followers yet.' : 'Not following anyone yet.'}</p>
        )}
        {users?.map((u) => (
          <Link key={u.id} className="user-row" to={`/profile/${u.username}`} onClick={onClose}>
            <Avatar user={u} size="sm" />
            <span className="info">
              <strong>{u.name}</strong>
              <span className="muted small">@{u.username}</span>
            </span>
          </Link>
        ))}
      </div>
    </Modal>
  );
}

export default function Profile() {
  const { username } = useParams();
  const { user: me, updateUser } = useAuth();
  const toast = useToast();
  const target = username || me.username;
  const [searchParams] = useSearchParams();

  const [profile, setProfile] = useState(null);
  const [status, setStatus] = useState('loading');
  const [errorMessage, setErrorMessage] = useState('');
  const [posts, setPosts] = useState([]);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [postsLoading, setPostsLoading] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [listType, setListType] = useState(null);

  // Load the profile whenever the username in the URL changes.
  useEffect(() => {
    let cancelled = false;
    setStatus('loading');
    setProfile(null);
    api.get(`/users/${encodeURIComponent(target)}`)
      .then((d) => {
        if (cancelled) return;
        setProfile(d.user);
        setStatus('ok');
      })
      .catch((err) => {
        if (cancelled) return;
        setErrorMessage(err.message);
        setStatus(err.status === 404 ? 'notfound' : 'error');
      });
    return () => { cancelled = true; };
  }, [target]);

  const profileName = profile?.username;

  // Settings links here with ?edit=1 to open the edit dialog directly.
  useEffect(() => {
    if (profile?.isSelf && searchParams.get('edit') === '1') setEditOpen(true);
  }, [profile, searchParams]);

  // Load the first page of posts once the profile is known.
  useEffect(() => {
    if (!profileName) return undefined;
    let cancelled = false;
    setPosts([]);
    setPage(0);
    setPostsLoading(true);
    api.get(`/users/${profileName}/posts?page=1&limit=10`)
      .then((d) => {
        if (cancelled) return;
        setPosts(d.posts);
        setPage(1);
        setHasMore(d.hasMore);
      })
      .catch((err) => { if (!cancelled) toast(err.message, 'error'); })
      .finally(() => { if (!cancelled) setPostsLoading(false); });
    return () => { cancelled = true; };
  }, [profileName]); // eslint-disable-line react-hooks/exhaustive-deps

  async function loadMorePosts() {
    const next = page + 1;
    setPostsLoading(true);
    try {
      const d = await api.get(`/users/${profileName}/posts?page=${next}&limit=10`);
      setPosts((list) => [...list, ...d.posts]);
      setPage(next);
      setHasMore(d.hasMore);
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setPostsLoading(false);
    }
  }

  // Keep the follower count correct without refetching the whole profile.
  function onFollowChange(next) {
    setProfile((p) => ({
      ...p,
      isFollowing: next,
      stats: { ...p.stats, followers: p.stats.followers + (next ? 1 : -1) },
    }));
  }

  function onSaved(updated) {
    setProfile((p) => ({ ...p, ...updated }));
    if (updated.id === me.id) updateUser({ ...me, ...updated });
    setEditOpen(false);
    toast('Profile updated');
  }

  if (status === 'loading') return <Skeletons count={2} />;
  if (status === 'notfound') {
    return (
      <EmptyState icon="fa-user-slash" title="User not found" text="This profile does not exist." actionTo="/" actionLabel="Back to home" />
    );
  }
  if (status === 'error') return <ErrorState message={errorMessage} onRetry={() => window.location.reload()} />;

  const isSelf = profile.isSelf;

  return (
    <>
      <section className="card profile-card">
        <div className="profile-cover">
          {profile.coverImage && <SafeImage className="cover-img" src={profile.coverImage} alt="" />}
        </div>
        <div className="profile-head">
          <Avatar user={profile} size="xl" />
          <div className="profile-actions">
            {isSelf ? (
              <button className="btn btn-outline btn-sm" type="button" onClick={() => setEditOpen(true)}>
                <i className="fa-solid fa-pen" aria-hidden="true" /> Edit profile
              </button>
            ) : (
              <FollowButton userId={profile.id} initialFollowing={profile.isFollowing} onChange={onFollowChange} />
            )}
          </div>
        </div>

        <div className="profile-info">
          <h1 className="profile-name">{profile.name}</h1>
          <p className="muted">@{profile.username}</p>
          {profile.bio && <p className="bio">{profile.bio}</p>}
          <ul className="profile-meta">
            {profile.location && (
              <li><i className="fa-solid fa-location-dot" aria-hidden="true" />{profile.location}</li>
            )}
            {profile.website && (
              <li>
                <i className="fa-solid fa-link" aria-hidden="true" />
                <a href={profile.website} target="_blank" rel="noopener noreferrer">
                  {profile.website.replace(/^https?:\/\//, '')}
                </a>
              </li>
            )}
            <li><i className="fa-regular fa-calendar" aria-hidden="true" />Joined {formatDate(profile.createdAt)}</li>
          </ul>
        </div>

        <div className="profile-stats">
          <div>
            <span className="stat-value">{profile.stats.posts}</span>
            <span className="stat-label">Posts</span>
          </div>
          <button type="button" className="profile-stat" onClick={() => setListType('followers')}>
            <span className="stat-value">{profile.stats.followers}</span>
            <span className="stat-label">Followers</span>
          </button>
          <button type="button" className="profile-stat" onClick={() => setListType('following')}>
            <span className="stat-value">{profile.stats.following}</span>
            <span className="stat-label">Following</span>
          </button>
        </div>
      </section>

      <h2 className="section-title">Posts</h2>
      <section className="feed">
        {posts.map((p) => (
          <PostCard key={p.id} post={p} onDelete={(id) => setPosts((list) => list.filter((x) => x.id !== id))} />
        ))}
        {postsLoading && <Skeletons count={2} />}
        {!postsLoading && posts.length === 0 && (
          <EmptyState
            icon="fa-pen-nib"
            title={isSelf ? 'Share your first post' : 'No posts yet'}
            text={isSelf ? 'Your posts will appear here.' : `@${profile.username} has not posted anything yet.`}
            actionTo={isSelf ? '/#composer' : undefined}
            actionLabel="Create a post"
          />
        )}
      </section>

      {hasMore && (
        <div className="load-more-wrap">
          <button className="btn btn-outline" type="button" disabled={postsLoading} onClick={loadMorePosts}>
            {postsLoading ? 'Loading…' : 'Load more'}
          </button>
        </div>
      )}

      {editOpen && <EditProfileModal profile={profile} onClose={() => setEditOpen(false)} onSaved={onSaved} />}
      {listType && <UserListModal username={profile.username} type={listType} onClose={() => setListType(null)} />}
    </>
  );
}
