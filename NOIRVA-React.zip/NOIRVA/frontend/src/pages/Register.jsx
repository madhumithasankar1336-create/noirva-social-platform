import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import Field from '../components/Field.jsx';
import PasswordField from '../components/PasswordField.jsx';
import { validateImageFile } from '../utils/format.js';

const EMPTY = { name: '', username: '', email: '', password: '', confirmPassword: '' };

export default function Register() {
  const { register } = useAuth();
  const toast = useToast();
  const [form, setForm] = useState(EMPTY);
  const [avatar, setAvatar] = useState(null);
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);

  const change = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  function pickAvatar(e) {
    const chosen = e.target.files[0];
    if (!chosen) return;
    const problem = validateImageFile(chosen);
    if (problem) {
      toast(problem, 'error');
      e.target.value = '';
      return;
    }
    setAvatar(chosen);
  }

  async function submit(e) {
    e.preventDefault();
    const errs = {};
    if (!form.name.trim()) errs.name = 'Full name is required';
    if (!form.username.trim()) errs.username = 'Username is required';
    if (!form.email.trim()) errs.email = 'Email is required';
    if (form.password.length < 8) errs.password = 'Use at least 8 characters';
    if (form.password !== form.confirmPassword) errs.confirmPassword = 'Passwords do not match';
    setErrors(errs);
    if (Object.keys(errs).length) return;

    const fd = new FormData();
    Object.entries(form).forEach(([k, v]) => fd.append(k, v.trim()));
    if (avatar) fd.append('profilePicture', avatar);

    setFormError('');
    setBusy(true);
    try {
      await register(fd);
      toast('Welcome to NOIRVA');
    } catch (err) {
      setFormError(err.message);
      setErrors(err.errors || {});
      setBusy(false);
    }
  }

  return (
    <div className="auth-body">
      <main className="auth-wrap">
        <section className="card auth-card">
          <div className="auth-brand">
            <img className="auth-logo" src="/assets/logo.svg" alt="" />
            <h1 className="brand-wordmark">NOIRVA</h1>
            <p className="tagline">Create your place in the circle</p>
          </div>
          <form onSubmit={submit} noValidate>
            <Field label="Full name" name="name" autoComplete="name" maxLength={60} value={form.name} onChange={change} error={errors.name} />
            <Field label="Username" name="username" autoComplete="username" maxLength={20} value={form.username} onChange={change} error={errors.username} />
            <Field label="Email" name="email" type="email" autoComplete="email" maxLength={254} value={form.email} onChange={change} error={errors.email} />
            <PasswordField label="Password" name="password" autoComplete="new-password" value={form.password} onChange={change}
              error={errors.password} hint="At least 8 characters, with a letter and a number." />
            <PasswordField label="Confirm password" name="confirmPassword" autoComplete="new-password" value={form.confirmPassword}
              onChange={change} error={errors.confirmPassword} />
            <Field label="Profile picture (optional)" name="profilePicture" type="file"
              accept="image/jpeg,image/png,image/gif,image/webp" onChange={pickAvatar} />
            {formError && <p className="form-error" role="alert">{formError}</p>}
            <button className="btn btn-gold btn-block" type="submit" disabled={busy}>
              {busy ? 'Creating account…' : 'Create account'}
            </button>
          </form>
          <p className="muted center auth-footer">Already a member? <Link to="/login">Sign in</Link></p>
        </section>
      </main>
    </div>
  );
}
