// Single HTTP layer for the whole app. Always sends cookies and the CSRF header.
const BASE = import.meta.env.VITE_API_BASE || 'http://localhost:5000/api';
export const API_ORIGIN = BASE.replace(/\/api\/?$/, '');

export function mediaUrl(path) {
  if (!path) return '';
  return /^https?:\/\//.test(path) ? path : API_ORIGIN + path;
}

export class ApiError extends Error {
  constructor(message, status = 0, errors = null) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.errors = errors;
  }
}

export async function apiRequest(path, { method = 'GET', body, formData, signal, silentAuth = false } = {}) {
  const headers = { Accept: 'application/json', 'X-Requested-With': 'NOIRVA' };
  let payload;
  if (formData) {
    payload = formData; // browser sets the multipart boundary
  } else if (body !== undefined) {
    headers['Content-Type'] = 'application/json';
    payload = JSON.stringify(body);
  }

  let res;
  try {
    res = await fetch(BASE + path, { method, headers, body: payload, credentials: 'include', signal });
  } catch (err) {
    if (err.name === 'AbortError') throw err;
    throw new ApiError('Cannot reach the NOIRVA server. Check that the backend is running.', 0);
  }

  let data = {};
  try {
    data = await res.json();
  } catch {
    // Non-JSON body; use the generic message below.
  }

  if (!res.ok) {
    if (res.status === 401 && !silentAuth && !path.startsWith('/auth/')) {
      window.dispatchEvent(new Event('noirva:unauthorized'));
    }
    throw new ApiError(data.message || `Request failed (${res.status})`, res.status, data.errors || null);
  }
  return data;
}

export const api = {
  get: (path, opts) => apiRequest(path, opts),
  post: (path, body) => apiRequest(path, { method: 'POST', body }),
  put: (path, body) => apiRequest(path, { method: 'PUT', body }),
  patch: (path, body) => apiRequest(path, { method: 'PATCH', body }),
  del: (path, body) => apiRequest(path, { method: 'DELETE', body }),
  upload: (path, method, formData) => apiRequest(path, { method, formData }),
};
