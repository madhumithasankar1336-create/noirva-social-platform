import { useState } from 'react';
import { mediaUrl } from '../api/client.js';

const DEFAULT_AVATAR = '/assets/default-avatar.svg';

export default function Avatar({ user, size = '' }) {
  const [failed, setFailed] = useState(false);
  const src = !failed && user?.profilePicture ? mediaUrl(user.profilePicture) : DEFAULT_AVATAR;
  return (
    <img
      className={`avatar ${size}`.trim()}
      src={src}
      alt=""
      loading="lazy"
      onError={() => setFailed(true)}
    />
  );
}
