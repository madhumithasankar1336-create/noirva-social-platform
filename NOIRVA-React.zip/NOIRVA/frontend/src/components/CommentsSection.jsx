import { useEffect, useState } from 'react';
import { api } from '../api/client.js';
import { useToast } from '../context/ToastContext.jsx';
import { timeAgo } from '../utils/format.js';
import Avatar from './Avatar.jsx';

export default function CommentsSection({ postId, onCountChange }) {
  const toast = useToast();
  const [comments, setComments] = useState([]);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState('');

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api.get(`/posts/${postId}/comments?page=1&limit=20`)
      .then((d) => {
        if (cancelled) return;
        setComments(d.comments);
        setPage(1);
        setHasMore(d.hasMore);
      })
      .catch((err) => {
        if (!cancelled) toast(err.message, 'error');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [postId]); // eslint-disable-line react-hooks/exhaustive-deps

  async function loadMore() {
    const next = page + 1;
    try {
      const d = await api.get(`/posts/${postId}/comments?page=${next}&limit=20`);
      setComments((list) => [...list, ...d.comments]);
      setPage(next);
      setHasMore(d.hasMore);
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  async function submit(e) {
    e.preventDefault();
    const content = text.trim();
    if (!content) return;
    setSending(true);
    try {
      const res = await api.post(`/posts/${postId}/comments`, { content });
      setComments((list) => [...list, res.comment]);
      setText('');
      onCountChange(res.commentCount);
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setSending(false);
    }
  }

  async function saveEdit(id) {
    const content = editText.trim();
    if (!content) return toast('Comment cannot be empty', 'error');
    try {
      const res = await api.put(`/comments/${id}`, { content });
      setComments((list) => list.map((c) => (c.id === id ? res.comment : c)));
      setEditingId(null);
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  async function remove(id) {
    if (!window.confirm('Delete this comment?')) return;
    try {
      const res = await api.del(`/comments/${id}`);
      setComments((list) => list.filter((c) => c.id !== id));
      onCountChange(res.commentCount);
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  return (
    <section className="comments" aria-label="Comments">
      {loading ? (
        <p className="muted small">Loading comments…</p>
      ) : comments.length === 0 ? (
        <p className="muted small">No comments yet. Start the conversation.</p>
      ) : (
        <div className="comment-list">
          {comments.map((c) => (
            <div className="comment" key={c.id}>
              <Avatar user={c.author} size="sm" />
              <div className="comment-main">
                <div className="comment-meta">
                  <strong>{c.author ? c.author.name : 'Deleted user'}</strong>
                  <span className="muted">
                    {c.author ? `@${c.author.username} · ` : ''}
                    {timeAgo(c.createdAt)}
                  </span>
                  {c.isOwner && editingId !== c.id && (
                    <div className="comment-actions">
                      <button className="icon-btn" type="button" aria-label="Edit comment"
                        onClick={() => { setEditingId(c.id); setEditText(c.content); }}>
                        <i className="fa-solid fa-pen" aria-hidden="true" />
                      </button>
                      <button className="icon-btn" type="button" aria-label="Delete comment" onClick={() => remove(c.id)}>
                        <i className="fa-solid fa-trash" aria-hidden="true" />
                      </button>
                    </div>
                  )}
                </div>
                {editingId === c.id ? (
                  <div className="inline-edit">
                    <textarea className="input" rows={2} maxLength={300} value={editText}
                      onChange={(e) => setEditText(e.target.value)} aria-label="Edit comment" />
                    <div className="row-end">
                      <button className="btn btn-outline btn-sm" type="button" onClick={() => setEditingId(null)}>Cancel</button>
                      <button className="btn btn-gold btn-sm" type="button" onClick={() => saveEdit(c.id)}>Save</button>
                    </div>
                  </div>
                ) : (
                  <div className="comment-text">{c.content}</div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {hasMore && (
        <button className="btn btn-ghost btn-sm" type="button" onClick={loadMore}>
          Load more comments
        </button>
      )}

      <form className="comment-form" onSubmit={submit}>
        <textarea className="input" rows={1} maxLength={300} placeholder="Write a comment…"
          value={text} onChange={(e) => setText(e.target.value)} aria-label="Write a comment" />
        <button className="btn btn-gold btn-sm" type="submit" disabled={sending || !text.trim()}>
          Post
        </button>
      </form>
    </section>
  );
}
