import { Navigate, Outlet, useLocation, useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import Layout from './Layout.jsx';
import { LoadingScreen } from './States.jsx';

// Only allows in-app paths, which blocks open-redirect attacks through ?next=.
export function safeNext(value) {
  return value && value.startsWith('/') && !value.startsWith('//') ? value : '/';
}

// Protected routes: redirect guests to login, otherwise render the app shell.
export function RequireAuth() {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <LoadingScreen />;
  if (!user) {
    return <Navigate to={`/login?next=${encodeURIComponent(location.pathname + location.search)}`} replace />;
  }
  return (
    <Layout>
      <Outlet />
    </Layout>
  );
}

// Login and register: logged-in users are sent to where they were heading.
export function GuestRoute() {
  const { user, loading } = useAuth();
  const [params] = useSearchParams();
  if (loading) return <LoadingScreen />;
  if (user) return <Navigate to={safeNext(params.get('next'))} replace />;
  return <Outlet />;
}
