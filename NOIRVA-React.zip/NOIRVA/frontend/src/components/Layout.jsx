import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useNotifications } from '../context/NotificationContext.jsx';
import Avatar from './Avatar.jsx';
import RightRail from './RightRail.jsx';

// "plain" items are not highlighted as active (Create Post is an action, not a page).
const NAV = [
  { to: '/', label: 'Home', icon: 'fa-house', end: true },
  { to: '/explore', label: 'Explore', icon: 'fa-compass' },
  { to: '/#composer', label: 'Create Post', icon: 'fa-square-plus', plain: true },
  { to: '/notifications', label: 'Notifications', icon: 'fa-bell', badge: true },
  { to: '/profile', label: 'My Profile', icon: 'fa-user' },
  { to: '/settings', label: 'Settings', icon: 'fa-gear' },
];
const MOBILE_TO = ['/', '/explore', '/#composer', '/notifications', '/profile'];

export function Brand() {
  return (
    <Link to="/" className="brand" aria-label="NOIRVA home">
      <span className="logo-mark"><span>N</span></span>
      <span className="brand-name">NOIRVA</span>
    </Link>
  );
}

export default function Layout({ children }) {
  const { user, logout } = useAuth();
  const { unread } = useNotifications();
  const navigate = useNavigate();
  const badgeText = unread > 9 ? '9+' : unread;

  async function handleLogout() {
    await logout();
    navigate('/login', { replace: true });
  }

  return (
    <>
      <header className="topbar">
        <Brand />
        <Link to={`/profile/${user.username}`} aria-label="My profile">
          <Avatar user={user} size="sm" />
        </Link>
      </header>

      <div className="app-layout">
        <aside className="sidebar" aria-label="Sidebar">
          <Brand />
          <nav className="side-nav" aria-label="Main navigation">
            {NAV.map((item) =>
              item.plain ? (
                <Link key={item.to} to={item.to} className="nav-link">
                  <i className={`fa-solid ${item.icon}`} aria-hidden="true" />
                  <span>{item.label}</span>
                </Link>
              ) : (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.end}
                  className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}
                >
                  <i className={`fa-solid ${item.icon}`} aria-hidden="true" />
                  <span>{item.label}</span>
                  {item.badge && unread > 0 && <span className="notif-badge">{badgeText}</span>}
                </NavLink>
              )
            )}
          </nav>
          <button className="nav-link logout-btn" type="button" onClick={handleLogout}>
            <i className="fa-solid fa-right-from-bracket" aria-hidden="true" />
            <span>Logout</span>
          </button>
          <div className="sidebar-user">
            <Avatar user={user} size="sm" />
            <div>
              <strong>{user.name}</strong>
              <span className="muted small">@{user.username}</span>
            </div>
          </div>
        </aside>

        <main className="main-content" id="main">
          {children}
        </main>

        <aside className="right-rail" aria-label="Discover">
          <RightRail />
        </aside>
      </div>

      <nav className="bottom-nav" aria-label="Mobile navigation">
        {NAV.filter((i) => MOBILE_TO.includes(i.to)).map((item) =>
          item.plain ? (
            <Link key={item.to} to={item.to} aria-label={item.label} title={item.label}>
              <i className={`fa-solid ${item.icon}`} aria-hidden="true" />
            </Link>
          ) : (
            <NavLink key={item.to} to={item.to} end={item.end} aria-label={item.label} title={item.label}>
              <i className={`fa-solid ${item.icon}`} aria-hidden="true" />
              {item.badge && unread > 0 && <span className="notif-badge">{badgeText}</span>}
            </NavLink>
          )
        )}
      </nav>
    </>
  );
}
