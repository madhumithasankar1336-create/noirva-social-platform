import { useState } from 'react';
import { mediaUrl } from '../api/client.js';

// Shows the fallback (or nothing) if the image is missing or fails to load.
export default function SafeImage({ src, alt = '', className, fallback = null }) {
  const [failed, setFailed] = useState(false);
  if (failed || !src) return fallback;
  return <img className={className} src={mediaUrl(src)} alt={alt} loading="lazy" onError={() => setFailed(true)} />;
}
