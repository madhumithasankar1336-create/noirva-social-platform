import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client.js';
import { useToast } from '../context/ToastContext.jsx';
import { timeAgo } from '../utils/format.js';
import Avatar from './Avatar.jsx';
import CommentsSection from './CommentsSection.jsx';
import RichText from './RichText.jsx';
import SafeImage from './SafeImage.jsx';

export default function PostCard({ post, onDelete, initialCommentsOpen = false }) {
  const toast = useToast();
  const menuRef = useRef(null);

  const [liked, setLiked] = useState(post.likedByMe);
  const [likeCount, setLikeCount] = useState(post.likeCount);
  const [commentCount, setCommentCount] = useState(post.commentCount);
  const [content, setContent] = useState(post.content);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState('');
  const [saving, setSaving] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [likeBusy, setLikeBusy] = useState(false);
  const [popping, setPopping] = useState(false);
  const [showComments, setShowComments] = useState(initialCommentsOpen);

  // Close the "more" menu when clicking anywhere else.
  useEffect(() => {
    if (!menuOpen) return undefined;
    const onDown = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [menuOpen]);

  async function toggleLike() {
    if (likeBusy) return;
    setLikeBusy(true);
    try {
      const res = liked ? await api.del(`/posts/${post.id}/like`) : await api.post(`/posts/${post.id}/like`);
      setLiked(res.liked);
      setLikeCount(res.likeCount);
      if (res.liked) {
        setPopping(true);
        setTimeout(() => setPopping(false), 400);
      }
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setLikeBusy(false);
    }
  }

  async function copyLink() {
    setMenuOpen(false);
    const url = `${window.location.origin}/post/${post.id}`;
    try {
      await navigator.clipboard.writeText(url);
      toast('Post link copied');
    } catch {
      toast(url);
    }
  }

  function startEdit() {
    setMenuOpen(false);
    setDraft(content);
    setEditing(true);
  }

  async function saveEdit() {
    const text = draft.trim();
    if (!text && !post.imageUrl) return toast('A post needs text or an image', 'error');
    setSaving(true);
    try {
      const res = await api.put(`/posts/${post.id}`, { content: text });
      setContent(res.post.content);
      setEditing(false);
      toast('Post updated');
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setSaving(false);
    }
  }

  async function remove() {
    setMenuOpen(false);
    if (!window.confirm('Delete this post? This cannot be undone.')) return;
    try {
      await api.del(`/posts/${post.id}`);
      toast('Post deleted');
      onDelete?.(post.id);
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  const { author } = post;

  return (
    <article className="card post-card">
      <header className="post-header">
        {author ? (
          <Link className="author-link" to={`/profile/${author.username}`}>
            <Avatar user={author} size="sm" />
            <span className="author-names">
              <strong>{author.name}</strong>
              <span className="muted small">@{author.username}</span>
            </span>
          </Link>
        ) : (
          <span className="muted small">Deleted user</span>
        )}

        <div className="post-right">
          <time className="muted small" dateTime={post.createdAt}>{timeAgo(post.createdAt)}</time>
          <div className="post-more" ref={menuRef}>
            <button className="icon-btn" type="button" aria-label="More options" aria-haspopup="menu"
              aria-expanded={menuOpen} onClick={() => setMenuOpen((o) => !o)}>
              <i className="fa-solid fa-ellipsis" aria-hidden="true" />
            </button>
            {menuOpen && (
              <div className="dropdown" role="menu">
                <button className="dropdown-item" type="button" role="menuitem" onClick={copyLink}>
                  <i className="fa-solid fa-link" aria-hidden="true" />Copy link
                </button>
                {post.isOwner && (
                  <>
                    <button className="dropdown-item" type="button" role="menuitem" onClick={startEdit}>
                      <i className="fa-solid fa-pen" aria-hidden="true" />Edit post
                    </button>
                    <button className="dropdown-item danger" type="button" role="menuitem" onClick={remove}>
                      <i className="fa-solid fa-trash" aria-hidden="true" />Delete post
                    </button>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </header>

      {editing ? (
        <div className="inline-edit">
          <textarea className="input" rows={3} maxLength={500} value={draft}
            onChange={(e) => setDraft(e.target.value)} aria-label="Edit post text" />
          <div className="row-end">
            <button className="btn btn-outline btn-sm" type="button" onClick={() => setEditing(false)}>Cancel</button>
            <button className="btn btn-gold btn-sm" type="button" disabled={saving} onClick={saveEdit}>
              {saving ? 'Saving…' : 'Save'}
            </button>
          </div>
        </div>
      ) : (
        content && <div className="post-content"><RichText text={content} /></div>
      )}

      {post.imageUrl && (
        <SafeImage
          className="post-image"
          src={post.imageUrl}
          alt="Post image"
          fallback={<div className="image-missing">This image is no longer available</div>}
        />
      )}

      <footer className="post-actions">
        <button
          type="button"
          className={`action-btn like-btn${liked ? ' liked' : ''}${popping ? ' pop' : ''}`}
          aria-pressed={liked}
          aria-label={liked ? 'Unlike' : 'Like'}
          onClick={toggleLike}
        >
          <i className={`${liked ? 'fa-solid' : 'fa-regular'} fa-heart`} aria-hidden="true" />
          <span className="count like-count">{likeCount}</span>
        </button>
        <button type="button" className="action-btn" aria-expanded={showComments} aria-label="Comments"
          onClick={() => setShowComments((s) => !s)}>
          <i className="fa-regular fa-comment" aria-hidden="true" />
          <span className="count comment-count">{commentCount}</span>
        </button>
        <button type="button" className="action-btn" aria-label="Copy post link" onClick={copyLink}>
          <i className="fa-solid fa-share-nodes" aria-hidden="true" />
        </button>
      </footer>

      {showComments && <CommentsSection postId={post.id} onCountChange={setCommentCount} />}
    </article>
  );
}
