import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client.js';
import Avatar from './Avatar.jsx';
import FollowButton from './FollowButton.jsx';

function Card({ title, children }) {
  return (
    <section className="card rail-card">
      <h3>{title}</h3>
      {children}
    </section>
  );
}

export default function RightRail() {
  const [data, setData] = useState(null);

  useEffect(() => {
    let cancelled = false;
    Promise.allSettled([
      api.get('/users/suggestions'),
      api.get('/search/trending'),
      api.get('/posts?tab=popular&limit=3'),
      api.get('/users/stats'),
    ]).then(([s, t, p, st]) => {
      if (cancelled) return;
      setData({
        suggestions: s.value?.users || [],
        trends: t.value?.tags || [],
        popular: p.value?.posts || [],
        stats: st.value?.stats || null,
      });
    });
    return () => {
      cancelled = true;
    };
  }, []);

  if (!data) {
    return <Card title="Discover"><p className="muted small">Loading…</p></Card>;
  }

  return (
    <>
      <Card title="Suggested for you">
        {data.suggestions.length ? (
          <ul className="rail-list">
            {data.suggestions.slice(0, 4).map((u) => (
              <li key={u.id} className="rail-user">
                <Avatar user={u} size="sm" />
                <div className="info">
                  <Link to={`/profile/${u.username}`}>{u.name}</Link>
                  <span className="muted small">@{u.username}</span>
                </div>
                <FollowButton userId={u.id} />
              </li>
            ))}
          </ul>
        ) : (
          <p className="muted small">No suggestions right now.</p>
        )}
      </Card>

      <Card title="Trending hashtags">
        {data.trends.length ? (
          <div className="tag-list">
            {data.trends.map((t) => (
              <Link key={t.tag} to={`/explore?tag=${encodeURIComponent(t.tag)}`}>
                <span className="hashtag">#{t.tag}</span>
                <span className="muted small">{t.count} post{t.count === 1 ? '' : 's'}</span>
              </Link>
            ))}
          </div>
        ) : (
          <p className="muted small">No trends in the last 7 days yet.</p>
        )}
      </Card>

      <Card title="Popular posts">
        {data.popular.length ? (
          <ul className="rail-list">
            {data.popular.map((p) => (
              <li key={p.id} className="rail-item">
                <Link className="snippet" to={`/post/${p.id}`}>{p.content || 'Image post'}</Link>
                <span className="muted small">{p.likeCount} likes</span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="muted small">Popular posts will appear here.</p>
        )}
      </Card>

      <Card title="Community">
        {data.stats && (
          <div className="stat-grid">
            <div><span className="stat-num">{data.stats.users.toLocaleString()}</span><span className="stat-label">Members</span></div>
            <div><span className="stat-num">{data.stats.posts.toLocaleString()}</span><span className="stat-label">Posts</span></div>
            <div><span className="stat-num">{data.stats.comments.toLocaleString()}</span><span className="stat-label">Comments</span></div>
            <div><span className="stat-num">{data.stats.likes.toLocaleString()}</span><span className="stat-label">Likes</span></div>
          </div>
        )}
      </Card>
    </>
  );
}
