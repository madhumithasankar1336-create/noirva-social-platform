import { Link } from 'react-router-dom';

const TAG_RE = /^#[A-Za-z0-9_]{1,50}$/;

// Renders text safely (React escapes it) and turns #hashtags into Explore links.
export default function RichText({ text }) {
  return (
    <>
      {String(text || '')
        .split(/(#[A-Za-z0-9_]{1,50})/)
        .map((part, i) =>
          TAG_RE.test(part) ? (
            <Link key={i} className="hashtag" to={`/explore?tag=${encodeURIComponent(part.slice(1).toLowerCase())}`}>
              {part}
            </Link>
          ) : (
            <span key={i}>{part}</span>
          )
        )}
    </>
  );
}
