import { Link } from 'react-router-dom';

export function LoadingScreen() {
  return (
    <div className="loading-screen" role="status" aria-label="Loading">
      <span className="loader" />
    </div>
  );
}

export function EmptyState({ icon = 'fa-feather-pointed', title, text, actionTo, actionLabel }) {
  return (
    <div className="empty-state">
      <div className="empty-icon">
        <i className={`fa-solid ${icon}`} aria-hidden="true" />
      </div>
      <h3>{title}</h3>
      {text && <p className="muted">{text}</p>}
      {actionTo && (
        <Link className="btn btn-gold btn-sm" to={actionTo}>
          {actionLabel || 'Continue'}
        </Link>
      )}
    </div>
  );
}

export function ErrorState({ message, onRetry }) {
  return (
    <div className="empty-state error-state" role="alert">
      <div className="empty-icon">
        <i className="fa-solid fa-triangle-exclamation" aria-hidden="true" />
      </div>
      <h3>Something went wrong</h3>
      <p className="muted">{message}</p>
      {onRetry && (
        <button className="btn btn-outline btn-sm" type="button" onClick={onRetry}>
          Try again
        </button>
      )}
    </div>
  );
}

export function Skeletons({ count = 3 }) {
  return Array.from({ length: count }, (_, i) => (
    <div key={i} className="card skeleton-card" aria-hidden="true" />
  ));
}
