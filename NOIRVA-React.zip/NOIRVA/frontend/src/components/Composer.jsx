import { useEffect, useRef, useState } from 'react';
import { api } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { validateImageFile } from '../utils/format.js';
import Avatar from './Avatar.jsx';

export default function Composer({ onPublished }) {
  const { user } = useAuth();
  const toast = useToast();
  const fileRef = useRef(null);
  const [text, setText] = useState('');
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState('');
  const [busy, setBusy] = useState(false);

  // Create an object URL for the preview and release it when the file changes.
  useEffect(() => {
    if (!file) {
      setPreview('');
      return undefined;
    }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  function pickFile(e) {
    const chosen = e.target.files[0];
    if (!chosen) return;
    const problem = validateImageFile(chosen);
    if (problem) {
      toast(problem, 'error');
      e.target.value = '';
      return;
    }
    setFile(chosen);
  }

  function clearImage() {
    setFile(null);
    if (fileRef.current) fileRef.current.value = '';
  }

  function reset() {
    setText('');
    clearImage();
  }

  async function submit(e) {
    e.preventDefault();
    const content = text.trim();
    if (!content && !file) return;
    const formData = new FormData();
    formData.append('content', content);
    if (file) formData.append('image', file);

    setBusy(true);
    try {
      const d = await api.upload('/posts', 'POST', formData);
      reset();
      toast('Your post is live');
      onPublished?.(d.post);
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setBusy(false);
    }
  }

  const canPublish = !busy && (text.trim() || file);

  return (
    <section className="card composer" id="composer" aria-label="Create a post">
      <form onSubmit={submit}>
        <div className="composer-top">
          <Avatar user={user} />
          <textarea
            id="composer-text"
            className="composer-input"
            rows={3}
            maxLength={500}
            placeholder="Share something worth noticing…"
            value={text}
            onChange={(e) => setText(e.target.value)}
            aria-label="Post text"
          />
        </div>

        {preview && (
          <div className="image-preview">
            <img src={preview} alt="Selected preview" />
            <button type="button" className="icon-btn remove-preview" aria-label="Remove image" onClick={clearImage}>
              <i className="fa-solid fa-xmark" aria-hidden="true" />
            </button>
          </div>
        )}

        <div className="composer-bottom">
          <label className="icon-btn" title="Add an image" style={{ cursor: 'pointer' }}>
            <i className="fa-regular fa-image" aria-hidden="true" />
            <span className="sr-only">Add an image</span>
            <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/gif,image/webp"
              className="sr-only" onChange={pickFile} />
          </label>
          <span className="char-count" aria-live="polite">{text.length}/500</span>
          <button type="button" className="btn btn-outline btn-sm" onClick={reset}>Cancel</button>
          <button type="submit" className="btn btn-gold btn-sm" disabled={!canPublish}>
            {busy ? 'Publishing…' : 'Publish'}
          </button>
        </div>
      </form>
    </section>
  );
}
