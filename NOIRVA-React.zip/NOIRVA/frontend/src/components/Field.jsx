import { useId } from 'react';

// Labelled form control with inline error text. Use as="textarea" for multi-line input.
export default function Field({ label, error, hint, as: Tag = 'input', ...rest }) {
  const id = useId();
  return (
    <div className="form-group">
      <label htmlFor={id}>{label}</label>
      <Tag id={id} className="input" aria-invalid={error ? true : undefined} {...rest} />
      {hint && <span className="muted small">{hint}</span>}
      {error && <span className="field-error">{error}</span>}
    </div>
  );
}
