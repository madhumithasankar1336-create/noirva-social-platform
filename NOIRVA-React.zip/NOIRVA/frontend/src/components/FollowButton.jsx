import { useEffect, useState } from 'react';
import { api } from '../api/client.js';
import { useToast } from '../context/ToastContext.jsx';

export default function FollowButton({ userId, initialFollowing = false, onChange }) {
  const toast = useToast();
  const [following, setFollowing] = useState(initialFollowing);
  const [busy, setBusy] = useState(false);

  useEffect(() => setFollowing(initialFollowing), [initialFollowing]);

  async function toggle() {
    setBusy(true);
    try {
      if (following) await api.del(`/users/${userId}/follow`);
      else await api.post(`/users/${userId}/follow`);
      const next = !following;
      setFollowing(next);
      onChange?.(next);
      toast(next ? 'You are now following' : 'Unfollowed');
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setBusy(false);
    }
  }

  return (
    <button
      type="button"
      className={`btn btn-sm ${following ? 'btn-secondary' : 'btn-gold'}`}
      disabled={busy}
      onClick={toggle}
    >
      {following ? 'Following' : 'Follow'}
    </button>
  );
}
