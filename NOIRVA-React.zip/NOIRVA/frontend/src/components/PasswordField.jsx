import { useId, useState } from 'react';

export default function PasswordField({ label, name, value, onChange, error, hint, autoComplete }) {
  const id = useId();
  const [show, setShow] = useState(false);
  return (
    <div className="form-group">
      <label htmlFor={id}>{label}</label>
      <div className="input-wrap">
        <input
          id={id}
          name={name}
          type={show ? 'text' : 'password'}
          className="input"
          value={value}
          onChange={onChange}
          autoComplete={autoComplete}
          aria-invalid={error ? true : undefined}
        />
        <button
          type="button"
          className="input-toggle"
          onClick={() => setShow((s) => !s)}
          aria-label={show ? 'Hide password' : 'Show password'}
        >
          <i className={show ? 'fa-regular fa-eye-slash' : 'fa-regular fa-eye'} aria-hidden="true" />
        </button>
      </div>
      {hint && <span className="muted small">{hint}</span>}
      {error && <span className="field-error">{error}</span>}
    </div>
  );
}
