# NOIRVA

> Your World. Your Circle. Your Noirva.

NOIRVA is a premium, black-and-gold social network. Users create profiles, publish posts with images, like and comment, follow each other, explore trending hashtags, and receive in-app notifications. The frontend is plain HTML, CSS, and Vanilla JavaScript. The backend is Node.js, Express, and MongoDB (Mongoose).

---

## 1. Project introduction

NOIRVA is a full-stack web application: a REST API, a MongoDB database, and a responsive static frontend that talks to the API with `fetch`. It is built to be run locally, demonstrated, and extended.

## 2. Project objectives

- Deliver a complete social loop: register, post, engage, follow, discover, and get notified.
- Keep security practical: bcrypt hashing, HttpOnly cookies, server-side authorization, input validation, safe uploads, and rate limiting.
- Keep the code modular, with one concern per file.
- Show database-backed behavior everywhere. No feed, search, count, or notification uses hardcoded data.

## 3. Feature list

| Area | Features |
| --- | --- |
| Auth | Register with profile picture, login by email or username, logout, current user, change password (signs out other sessions), delete account with reauthentication |
| Profiles | Cover and profile images, name, bio, location, website, join date, stats, follow or edit, followers and following lists, paginated posts |
| Posts | Create, view, edit text, delete, image upload with preview and removal, hashtags, copy link, owner-only menu |
| Comments | Add, paginated load, edit and delete own comments, live counts |
| Likes | Like and unlike, idempotent, unique index prevents duplicates, live counts |
| Follows | Follow and unfollow, self-follow and duplicate prevention, suggestions that exclude the current user |
| Feeds | For You (ranked), Following, Latest, plus Popular via the API |
| Explore | Debounced search of people, hashtags, and posts, plus suggestions, trending tags, popular and recent posts, and an image grid |
| Notifications | Follow, like, and comment notifications stored in MongoDB, unread badge, mark one or all as read, no self-notifications |
| UI | Black-and-gold design system, three-column desktop layout, tablet layout, mobile layout with bottom navigation, toasts, skeleton loaders, empty and error states |

Messaging and real-time (WebSocket) delivery are intentionally not included. Their navigation entries and screens are not shown.

## 4. Technology stack

- **Frontend:** HTML5, CSS3, Vanilla JavaScript (ES2020), Fetch API, Font Awesome 6, Google Fonts (Cinzel, Inter)
- **Backend:** Node.js 18.11+, Express 4, JWT (HS256) in an HttpOnly cookie, bcrypt, helmet, cors, cookie-parser, express-rate-limit, multer, dotenv
- **Database:** MongoDB with Mongoose 8
- **Testing:** Jest and Supertest

## 5. Architecture overview

```
Browser (static HTML/CSS/JS, port 5500)
   │  fetch + credentials: 'include' + X-Requested-With header
   ▼
Express API (port 5000, /api)
   ├─ helmet · cors (allowlist) · cookie-parser · JSON body limits
   ├─ CSRF header guard for state-changing requests
   ├─ global and auth rate limiters
   ├─ routes → controllers → models (Mongoose) → MongoDB
   ├─ middleware: requireAuth / optionalAuth, multer upload, error handler
   └─ services: notifications
```

Authentication uses an HttpOnly, SameSite=Lax cookie that holds a signed JWT. Each token includes a `tokenVersion`. Changing a password increments the version, which invalidates every older session.

Like and comment counts are computed with aggregation at read time. They are not stored as counters, so they cannot drift.

## 6. Folder structure

```
NOIRVA/
├── README.md
├── .gitignore
├── backend/
│   ├── package.json
│   ├── .env.example
│   ├── server.js              # boots DB + HTTP server
│   ├── app.js                 # Express app (middleware + routes)
│   ├── config/                # env validation, DB connection
│   ├── models/                # User, Post, Comment, Like, Follow, Notification
│   ├── controllers/           # auth, user, post, comment, like, follow, notification, search
│   ├── routes/                # one router per resource
│   ├── middleware/            # auth, upload, error handling
│   ├── services/              # notification service
│   ├── utils/                 # validators, serializers, image storage, post aggregation
│   ├── scripts/seed.js        # development demo data
│   ├── tests/                 # setup, helpers, auth, posts, social suites
│   └── uploads/               # runtime image storage (ignored by git)
└── frontend/
    ├── index.html             # home feed
    ├── explore.html · profile.html · notifications.html · settings.html · post.html
    ├── login.html · register.html
    ├── css/style.css          # design system and components
    ├── css/responsive.css     # breakpoints
    ├── js/config.js           # API base URL
    ├── js/api.js              # fetch wrapper
    ├── js/utils.js            # DOM helpers, toasts, formatting, validation
    ├── js/auth.js             # session checks, login and register forms
    ├── js/app.js              # shell, navigation, right rail, follow buttons, boot
    ├── js/feed.js · posts.js  # feed, composer, post cards, likes, comments
    ├── js/profile.js · explore.js · notifications.js · settings.js · post.js
    └── assets/                # logo.svg, default-avatar.svg
```

## 7. Prerequisites

- Node.js 18.11 or newer (Node 20 or 22 recommended)
- npm 9 or newer
- MongoDB 6 or newer, either local or Atlas
- Any static file server for the frontend (Python, VS Code Live Server, or `npx serve`)

## 8. Installation steps

```bash
cd NOIRVA/backend
npm install
cp .env.example .env          # Windows PowerShell: Copy-Item .env.example .env
```

Generate a strong JWT secret and paste it into `backend/.env`:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

## 9. Environment setup

Edit `backend/.env`:

| Variable | Purpose |
| --- | --- |
| `PORT` | API port (default `5000`) |
| `MONGODB_URI` | Main database connection string |
| `MONGODB_TEST_URI` | Separate database used only by the test suite. Its name must contain `test` |
| `JWT_SECRET` | At least 32 random characters. Startup fails if this is missing or too short |
| `CLIENT_URL` | Exact frontend origin allowed by CORS, for example `http://localhost:5500` |
| `NODE_ENV` | `development` locally, `production` when deployed (enables secure cookies and disables seeding) |
| `BCRYPT_ROUNDS` | Hashing cost. Default `12` |
| `SEED_PASSWORD` | Password for demo accounts created by `npm run seed` |

Never commit `backend/.env`. Only `.env.example` contains placeholders.

## 10. MongoDB local setup

1. Install MongoDB Community Server, or run it with Docker:
   ```bash
   docker run -d --name noirva-mongo -p 27017:27017 mongo:7
   ```
2. Use `MONGODB_URI=mongodb://127.0.0.1:27017/noirva` and `MONGODB_TEST_URI=mongodb://127.0.0.1:27017/noirva_test`.

## 11. MongoDB Atlas setup

1. Create a free cluster at cloud.mongodb.com.
2. Create a database user with a strong password under Database Access.
3. Under Network Access, allow your IP address (or a deployment platform's IPs for production).
4. Click Connect, choose "Drivers", and copy the URI. Put your real password in place of `<password>` and set it as `MONGODB_URI`. Use a separate cluster or database for `MONGODB_TEST_URI`.

## 12. Backend startup

```bash
cd backend
npm run dev        # auto-restarts on change (Node --watch)
# or
npm start
```

Expected output:

```
MongoDB connected: <host>/noirva
NOIRVA API running at http://localhost:5000/api (development)
```

Check it with `GET http://localhost:5000/api/health`.

## 13. Frontend startup

The frontend must be served over HTTP, not opened with `file://`, because browsers block cookies and `fetch` from `file://` origins. From the project root, use either:

```bash
cd frontend
python -m http.server 5500
# or: npx serve -l 5500 frontend
```

Then open **http://localhost:5500**. If you use a different port, update `CLIENT_URL` in `backend/.env` to match.

The API address is set in `frontend/js/config.js`:

```js
window.NOIRVA_CONFIG = { API_BASE: 'http://localhost:5000/api' };
```

## 14. API documentation

All responses are JSON. Errors use `{ "success": false, "message": "...", "errors": { field: "..." } }`. Mutating requests must send the header `X-Requested-With: NOIRVA`. Authenticated routes read the `noirva_token` cookie.

| Method | Path | Auth | Description |
| --- | --- | --- | --- |
| POST | `/api/auth/register` | — | multipart or JSON: `name, username, email, password, confirmPassword, profilePicture?` → 201 |
| POST | `/api/auth/login` | — | `{ identifier, password }` → 200, sets cookie |
| POST | `/api/auth/logout` | — | clears cookie |
| GET | `/api/auth/me` | ✔ | current user |
| POST | `/api/auth/change-password` | ✔ | `{ currentPassword, newPassword, confirmPassword }` |
| GET | `/api/users/stats` | — | community totals |
| GET | `/api/users/suggestions` | ✔ | up to 6 accounts the viewer does not follow |
| GET | `/api/users/:username` | optional | profile with stats, `isSelf`, `isFollowing` |
| PUT | `/api/users/me` | ✔ | multipart: `name, bio, location, website, profilePicture?, coverImage?` |
| DELETE | `/api/users/me` | ✔ | `{ password }`, permanently deletes the account and its content |
| GET | `/api/users/:username/posts` | optional | paginated posts (`page`, `limit`) |
| GET | `/api/users/:username/followers` | — | paginated follower list |
| GET | `/api/users/:username/following` | — | paginated following list |
| GET | `/api/posts` | optional | feed: `tab=for-you|following|latest|popular`, `page`, `limit` (max 20), `media=1` |
| GET | `/api/posts/following` | ✔ | shortcut for `tab=following` |
| GET | `/api/posts/:id` | optional | single post |
| POST | `/api/posts` | ✔ | multipart: `content?`, `image?`. Requires text or an image |
| PUT | `/api/posts/:id` | ✔ owner | `content`, optional `image` or `removeImage=true` |
| DELETE | `/api/posts/:id` | ✔ owner | removes the post, its likes, comments, notifications, and image |
| GET | `/api/posts/:id/comments` | optional | paginated, oldest first |
| POST | `/api/posts/:id/comments` | ✔ | `{ content }`, max 300 characters |
| PUT | `/api/comments/:id` | ✔ owner | `{ content }` |
| DELETE | `/api/comments/:id` | ✔ owner | returns the new `commentCount` |
| POST | `/api/posts/:id/like` | ✔ | 201 on new like, 200 if already liked |
| DELETE | `/api/posts/:id/like` | ✔ | unlike |
| POST | `/api/users/:id/follow` | ✔ | 201 on new follow, 200 if already following, 400 for self |
| DELETE | `/api/users/:id/follow` | ✔ | unfollow |
| GET | `/api/search/users?q=` | — | name or username search, up to 20 results |
| GET | `/api/search/posts?q=` | optional | post text or hashtag search, paginated |
| GET | `/api/search/hashtags?q=` | — | hashtag prefix search with real counts |
| GET | `/api/search/trending` | — | top hashtags from the last 7 days, computed from stored posts |
| GET | `/api/notifications` | ✔ | paginated list, `unreadCount` |
| PATCH | `/api/notifications/:id/read` | ✔ owner | 404 for anyone else's notification |
| PATCH | `/api/notifications/read-all` | ✔ | marks all unread as read |

## 15. Test commands

Tests need a separate database. Set `MONGODB_TEST_URI` in `backend/.env`, then run:

```bash
cd backend
npm test
```

Tests drop and recreate only the test database. The suite refuses to run if the database name does not contain `test`. Coverage: registration, duplicate prevention, login, logout, protected routes, password hashing, password change session invalidation, post permissions, upload validation, comment ownership, like and duplicate-like prevention, follow and duplicate-follow prevention, following feed filtering, notification authorization, and profile edit permissions.

## 16. Sample data setup

```bash
cd backend
npm run seed
```

This creates five demo accounts (`amara`, `julian`, `sofia`, `kai`, `nadia`), with emails in the form `<username>@noirva.demo` and the password from `SEED_PASSWORD`. It also creates posts, follows, likes, and comments. Seeding is refused when `NODE_ENV=production`, and it does nothing if demo data already exists.

## 17. Common errors and fixes

| Symptom | Cause and fix |
| --- | --- |
| `Missing environment variables: ...` | `backend/.env` is missing or incomplete. Copy `.env.example`. |
| `JWT_SECRET must be at least 32 characters` | Generate a longer secret with the command in section 8. |
| `Database connection failed` | MongoDB is not running, the URI is wrong, or Atlas network access is blocked. |
| Browser says `Cannot reach the NOIRVA server` | The API is not running on the address in `js/config.js`. |
| CORS error in the browser console | The frontend origin differs from `CLIENT_URL`. Use `http://localhost:5500` for both, not `127.0.0.1`. |
| Frontend immediately redirects to login | Cookies are blocked, or the page was opened with `file://`. Serve it over HTTP. |
| `403 Request blocked: missing security header` | A custom client is calling the API without `X-Requested-With: NOIRVA`. |
| `429 Too many attempts` | Login and registration are limited to 20 attempts per 15 minutes per IP. Wait or restart in development. |
| `bcrypt` install errors on Windows or Linux | Use Node 18 to 22 LTS. Prebuilt binaries are used when available. Otherwise install build tools. |
| Images show "no longer available" | The file was removed from `backend/uploads/`, or the API is serving from another host. |

## 18. Deployment instructions

**Backend (for example Render, Railway, or a VPS):**

1. Set environment variables from `.env.example`, with `NODE_ENV=production`, a strong `JWT_SECRET`, an Atlas `MONGODB_URI`, and `CLIENT_URL` set to the exact frontend URL.
2. Start command: `npm start`. Install command: `npm ci`.
3. Put the API behind HTTPS. Secure cookies are only sent over HTTPS in production.
4. Set `app.set('trust proxy', 1)` in `app.js` if the platform terminates TLS in front of Node, so rate limiting sees real client IPs.

**Frontend (for example Netlify, Vercel static, or Nginx):** Deploy the `frontend/` folder as-is. Set `API_BASE` in `js/config.js` to the production API URL. Put the frontend and API under one parent domain (for example `app.example.com` and `api.example.com`) so that SameSite=Lax cookies work.

**Uploads in production:** Local `uploads/` is not durable on most hosts. Move `saveImage` and `deleteImage` in `backend/utils/imageStorage.js` to an object store such as S3, Cloudinary, or Cloudflare R2. Store the returned public URLs in `profilePicture`, `coverImage`, and `imageUrl`. Keep the storage credentials in the server environment only.

## 19. Security considerations

- Passwords are hashed with bcrypt (default cost 12). Hashes are never returned by any endpoint (`select: false` and a `toJSON` transform).
- Login returns the same message for unknown users and wrong passwords, and runs a dummy hash comparison to equalize timing.
- JWTs are signed with HS256, stored in HttpOnly and SameSite=Lax cookies (Secure in production), and expire after 7 days. Password changes invalidate old tokens through `tokenVersion`.
- Authorization is checked on the server for every write. Frontend checks are only for user experience.
- CSRF: cookie-authenticated, state-changing requests must include a custom header. Browsers cannot send that header in cross-site forms, and CORS only allows the configured origin.
- Uploads are checked by magic bytes, not just MIME type. Files are renamed to random UUIDs, capped at 5 MB, and stored outside the code path. Deletion only accepts names matching the generated pattern, which blocks path traversal.
- Input is validated on the server. Search input is regex-escaped. JSON bodies are capped at 100 KB.
- The frontend renders user content with `textContent` and DOM APIs. It does not use `innerHTML` for user data, which blocks stored XSS.
- Rate limits apply globally to `/api` and specifically to registration and login.
- Helmet sets secure HTTP headers. Stack traces are logged on the server only.
- Secrets live in `.env`, which is git-ignored. Only placeholders are in `.env.example`.

**Production hardening steps to consider:** add email verification and a password reset flow with hashed, expiring tokens; use a Redis-backed rate limiter for multiple instances; add a Content-Security-Policy to the frontend host; add structured logging and monitoring; add refresh tokens with rotation; enable MongoDB role-based access control with a least-privilege user.

## 20. Future enhancements

- Forgot-password flow with email delivery
- Direct messaging with WebSocket delivery
- Real-time notifications
- Edit post images from the UI (the API already supports it)
- Comment and reply threads, plus a "show more" view on long posts
- Cursor-based pagination for very large feeds
- Object-storage uploads and image resizing
- Notification preferences
- Account-level content reporting and moderation tools
- Automated end-to-end browser tests (for example Playwright)

## Screenshots

_Placeholders until screenshots are captured:_

- `docs/screenshots/home-desktop.png`: Home feed, desktop
- `docs/screenshots/profile.png`: Profile with stats and posts
- `docs/screenshots/explore.png`: Explore search and discovery
- `docs/screenshots/mobile.png`: Mobile layout with bottom navigation

## Known limitations

- Forgot-password, email verification, and messaging are not implemented.
- The For You ranking is a simple engagement score over the last 30 days (`2 × likes + comments`, then recency). It is not personalized.
- Explore post search shows the first page of results (10) without a "load more" control.
- Post editing in the UI changes the text only. The API supports image replacement and removal.
- Comments are ordered oldest first with pagination and have no nested replies.
- Images are stored on local disk, so they are not suitable for multi-instance production without object storage.
- Like and comment counts are computed with `$lookup` at read time. This is fine for a demonstration-scale dataset, but very large feeds should move to stored counters with reconciliation.
- Rate limiting uses in-memory storage, which is per process.
- The frontend uses the browser's native confirm dialog for destructive actions.

## License

For educational and portfolio use.
