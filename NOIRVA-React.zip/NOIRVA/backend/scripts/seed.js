// Development-only demo data. Refuses to run in production.
require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');
const Post = require('../models/Post');
const Follow = require('../models/Follow');
const Like = require('../models/Like');
const Comment = require('../models/Comment');
const { hashPassword } = require('../utils/passwords');
const { extractHashtags } = require('../utils/validators');

const PEOPLE = [
  ['Amara Vale', 'amara', 'Quiet luxury, loud ideas.'],
  ['Julian Rowe', 'julian', 'Photographer chasing golden hours.'],
  ['Sofia Lenz', 'sofia', 'Architecture, coffee, and long walks.'],
  ['Kai Mendoza', 'kai', 'Building things in public.'],
  ['Nadia Frost', 'nadia', 'Poetry, film, and slow mornings.'],
];

const POSTS = [
  'Golden hour never disappoints. #photography #goldenhour',
  'Minimalism is not the absence of things, it is the presence of intention. #design',
  'Shipped a new feature today and I finally feel ready for the weekend. #buildinpublic',
  'Found a tiny bookshop with the best espresso in the city. #coffee #travel',
  'Sketching floor plans again. Light is the real material. #architecture #design',
];

(async () => {
  if (process.env.NODE_ENV === 'production') {
    console.error('Seeding is disabled when NODE_ENV=production.');
    process.exit(1);
  }
  if (!process.env.MONGODB_URI) {
    console.error('MONGODB_URI is not set. Configure backend/.env first.');
    process.exit(1);
  }
  if (!process.env.SEED_PASSWORD || process.env.SEED_PASSWORD.length < 8) {
    console.error('Set SEED_PASSWORD (at least 8 characters, letters and numbers) in backend/.env.');
    process.exit(1);
  }

  await mongoose.connect(process.env.MONGODB_URI);

  if (await User.exists({ email: /@noirva\.demo$/ })) {
    console.log('Demo data already exists. Nothing was changed.');
    await mongoose.disconnect();
    return;
  }

  const passwordHash = await hashPassword(process.env.SEED_PASSWORD);
  const users = await User.insertMany(
    PEOPLE.map(([name, username, bio]) => ({ name, username, email: `${username}@noirva.demo`, bio, passwordHash }))
  );

  const posts = [];
  for (let i = 0; i < POSTS.length; i++) {
    posts.push(
      await Post.create({
        author: users[i % users.length]._id,
        content: POSTS[i],
        hashtags: extractHashtags(POSTS[i]),
      })
    );
  }

  await Follow.insertMany([
    { follower: users[0]._id, following: users[1]._id },
    { follower: users[0]._id, following: users[2]._id },
    { follower: users[1]._id, following: users[0]._id },
    { follower: users[3]._id, following: users[0]._id },
  ]);

  await Like.insertMany([
    { post: posts[0]._id, user: users[0]._id },
    { post: posts[0]._id, user: users[2]._id },
    { post: posts[1]._id, user: users[1]._id },
  ]);

  await Comment.insertMany([
    { post: posts[0]._id, author: users[3]._id, content: 'Absolutely stunning light.' },
    { post: posts[2]._id, author: users[4]._id, content: 'Congratulations on shipping!' },
  ]);

  console.log(`Seeded ${users.length} demo users (emails: <username>@noirva.demo), ${posts.length} posts.`);
  await mongoose.disconnect();
})().catch((err) => {
  console.error('Seed failed:', err.message);
  process.exit(1);
});
