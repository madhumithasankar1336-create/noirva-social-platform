const express = require('express');
const { requireAuth } = require('../middleware/authMiddleware');
const c = require('../controllers/notificationController');

const router = express.Router();

router.get('/', requireAuth, c.list);
router.patch('/read-all', requireAuth, c.markAllRead);
router.patch('/:id/read', requireAuth, c.markRead);

module.exports = router;
