const express = require('express');
const { requireAuth, optionalAuth } = require('../middleware/authMiddleware');
const { uploadFields } = require('../middleware/uploadMiddleware');
const c = require('../controllers/userController');

const router = express.Router();

// Static paths are declared before "/:username" so they are not treated as usernames.
router.get('/stats', c.getStats);
router.get('/suggestions', requireAuth, c.getSuggestions);
router.put(
  '/me',
  requireAuth,
  uploadFields([
    { name: 'profilePicture', maxCount: 1 },
    { name: 'coverImage', maxCount: 1 },
  ]),
  c.updateMe
);
router.delete('/me', requireAuth, c.deleteAccount);
router.get('/:username', optionalAuth, c.getProfile);
router.get('/:username/posts', optionalAuth, c.getUserPosts);
router.get('/:username/followers', c.getFollowers);
router.get('/:username/following', c.getFollowing);

module.exports = router;
