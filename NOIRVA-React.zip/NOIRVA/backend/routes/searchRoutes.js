const express = require('express');
const { optionalAuth } = require('../middleware/authMiddleware');
const c = require('../controllers/searchController');

const router = express.Router();

router.get('/users', c.searchUsers);
router.get('/posts', optionalAuth, c.searchPosts);
router.get('/hashtags', c.searchHashtags);
router.get('/trending', c.getTrending);

module.exports = router;
