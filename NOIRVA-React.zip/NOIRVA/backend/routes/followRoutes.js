const express = require('express');
const { requireAuth } = require('../middleware/authMiddleware');
const c = require('../controllers/followController');

const router = express.Router();

router.post('/users/:id/follow', requireAuth, c.follow);
router.delete('/users/:id/follow', requireAuth, c.unfollow);

module.exports = router;
