const express = require('express');
const { requireAuth, optionalAuth } = require('../middleware/authMiddleware');
const c = require('../controllers/commentController');

const router = express.Router();

router.get('/posts/:id/comments', optionalAuth, c.getComments);
router.post('/posts/:id/comments', requireAuth, c.createComment);
router.put('/comments/:id', requireAuth, c.updateComment);
router.delete('/comments/:id', requireAuth, c.deleteComment);

module.exports = router;
