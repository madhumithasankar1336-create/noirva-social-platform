const express = require('express');
const rateLimit = require('express-rate-limit');
const { uploadSingle } = require('../middleware/uploadMiddleware');
const { requireAuth } = require('../middleware/authMiddleware');
const c = require('../controllers/authController');

const router = express.Router();

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: process.env.NODE_ENV === 'test' ? 10000 : 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many attempts. Please wait 15 minutes and try again.' },
});

router.post('/register', authLimiter, uploadSingle('profilePicture'), c.register);
router.post('/login', authLimiter, c.login);
router.post('/logout', c.logout);
router.get('/me', requireAuth, c.me);
router.post('/change-password', requireAuth, c.changePassword);

module.exports = router;
