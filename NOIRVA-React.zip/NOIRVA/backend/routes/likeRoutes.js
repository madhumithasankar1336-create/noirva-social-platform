const express = require('express');
const { requireAuth } = require('../middleware/authMiddleware');
const c = require('../controllers/likeController');

const router = express.Router();

router.post('/posts/:id/like', requireAuth, c.like);
router.delete('/posts/:id/like', requireAuth, c.unlike);

module.exports = router;
