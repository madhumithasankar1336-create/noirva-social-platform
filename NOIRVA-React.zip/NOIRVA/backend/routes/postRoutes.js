const express = require('express');
const { requireAuth, optionalAuth } = require('../middleware/authMiddleware');
const { uploadSingle } = require('../middleware/uploadMiddleware');
const c = require('../controllers/postController');

const router = express.Router();

router.get('/', optionalAuth, c.getFeed);
router.get('/following', requireAuth, c.getFollowingFeed);
router.get('/:id', optionalAuth, c.getPost);
router.post('/', requireAuth, uploadSingle('image'), c.createPost);
router.put('/:id', requireAuth, uploadSingle('image'), c.updatePost);
router.delete('/:id', requireAuth, c.deletePost);

module.exports = router;
