require('dotenv').config();
const { loadConfig } = require('./config/env');
const connectDB = require('./config/db');

async function start() {
  const config = loadConfig();
  await connectDB(config.mongoUri);
  const app = require('./app');
  app.listen(config.port, () => {
    console.log(`NOIRVA API running at http://localhost:${config.port}/api (${config.nodeEnv})`);
  });
}

start().catch((err) => {
  console.error(`Startup failed: ${err.message}`);
  process.exit(1);
});
