const mongoose = require('mongoose');
const { Schema } = mongoose;

const followSchema = new Schema(
  {
    follower: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    following: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    createdAt: { type: Date, default: Date.now },
  },
  { versionKey: false }
);

followSchema.index({ follower: 1, following: 1 }, { unique: true });
followSchema.index({ following: 1, createdAt: -1 });
followSchema.index({ follower: 1, createdAt: -1 });

followSchema.pre('validate', function (next) {
  if (this.follower && this.following && this.follower.equals(this.following)) {
    this.invalidate('following', 'Users cannot follow themselves');
  }
  next();
});

module.exports = mongoose.model('Follow', followSchema);
