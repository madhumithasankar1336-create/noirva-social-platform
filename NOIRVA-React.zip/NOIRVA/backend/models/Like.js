const mongoose = require('mongoose');
const { Schema } = mongoose;

const likeSchema = new Schema(
  {
    post: { type: Schema.Types.ObjectId, ref: 'Post', required: true },
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    createdAt: { type: Date, default: Date.now },
  },
  { versionKey: false }
);

likeSchema.index({ post: 1, user: 1 }, { unique: true });
likeSchema.index({ user: 1 });

module.exports = mongoose.model('Like', likeSchema);
