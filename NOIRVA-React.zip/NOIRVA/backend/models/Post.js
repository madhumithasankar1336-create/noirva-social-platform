const mongoose = require('mongoose');
const { Schema } = mongoose;

const postSchema = new Schema(
  {
    author: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    content: { type: String, default: '', trim: true, maxlength: 500 },
    imageUrl: { type: String, default: '' },
    hashtags: { type: [String], default: [], index: true },
  },
  { timestamps: true }
);

postSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Post', postSchema);
