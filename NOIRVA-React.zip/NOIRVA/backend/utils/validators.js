const ApiError = require('./ApiError');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const USERNAME_RE = /^[a-z0-9_]{3,20}$/;
const OBJECT_ID_RE = /^[a-f0-9]{24}$/i;
const URL_RE = /^https?:\/\/\S+$/i;

const clean = (value) => (typeof value === 'string' ? value.trim() : '');
const fail = (errors) => {
  throw new ApiError(400, 'Validation failed', errors);
};

function validatePassword(password) {
  if (typeof password !== 'string' || password.length < 8 || password.length > 128) {
    return 'Password must be 8 to 128 characters';
  }
  if (!/[A-Za-z]/.test(password) || !/\d/.test(password)) {
    return 'Password must include at least one letter and one number';
  }
  return null;
}

function validateRegister(body = {}) {
  const errors = {};
  const name = clean(body.name);
  const username = clean(body.username).toLowerCase();
  const email = clean(body.email).toLowerCase();

  if (!name || name.length > 60) errors.name = 'Full name is required (max 60 characters)';
  if (!USERNAME_RE.test(username)) {
    errors.username = 'Username must be 3 to 20 characters: letters, numbers, or underscores';
  }
  if (!EMAIL_RE.test(email) || email.length > 254) errors.email = 'Enter a valid email address';
  const passwordError = validatePassword(body.password);
  if (passwordError) errors.password = passwordError;
  if (body.password !== body.confirmPassword) errors.confirmPassword = 'Passwords do not match';

  if (Object.keys(errors).length) fail(errors);
  return { name, username, email, password: body.password };
}

function validateLogin(body = {}) {
  const identifier = clean(body.identifier).toLowerCase();
  const errors = {};
  if (!identifier || identifier.length > 254) errors.identifier = 'Enter your email or username';
  if (typeof body.password !== 'string' || !body.password) errors.password = 'Enter your password';
  if (Object.keys(errors).length) fail(errors);
  return { identifier, password: body.password };
}

function validateProfileUpdate(body = {}) {
  const errors = {};
  const updates = {};

  if (body.name !== undefined) {
    const v = clean(body.name);
    if (!v || v.length > 60) errors.name = 'Name must be 1 to 60 characters';
    else updates.name = v;
  }
  if (body.bio !== undefined) {
    const v = clean(body.bio);
    if (v.length > 160) errors.bio = 'Bio must be 160 characters or fewer';
    else updates.bio = v;
  }
  if (body.location !== undefined) {
    const v = clean(body.location);
    if (v.length > 80) errors.location = 'Location must be 80 characters or fewer';
    else updates.location = v;
  }
  if (body.website !== undefined) {
    const v = clean(body.website);
    if (v && (v.length > 200 || !URL_RE.test(v))) errors.website = 'Website must be a valid http or https URL';
    else updates.website = v;
  }

  if (Object.keys(errors).length) fail(errors);
  return updates;
}

function validatePostContent(content) {
  const v = clean(content);
  if (v.length > 500) fail({ content: 'Posts can be at most 500 characters' });
  return v;
}

function validateComment(content) {
  const v = clean(content);
  if (!v) fail({ content: 'Comment cannot be empty' });
  if (v.length > 300) fail({ content: 'Comments can be at most 300 characters' });
  return v;
}

function validateObjectId(id, label = 'resource') {
  if (!OBJECT_ID_RE.test(String(id))) throw new ApiError(400, `Invalid ${label} ID`);
  return String(id);
}

function validateSearchQuery(q) {
  const v = clean(typeof q === 'string' ? q : '');
  if (!v || v.length > 100) throw new ApiError(400, 'Search must be 1 to 100 characters');
  return v;
}

function parsePagination(query = {}, { defaultLimit = 10, maxLimit = 50 } = {}) {
  const page = Math.min(1000, Math.max(1, parseInt(query.page, 10) || 1));
  const limit = Math.min(maxLimit, Math.max(1, parseInt(query.limit, 10) || defaultLimit));
  return { page, limit };
}

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

function extractHashtags(text = '') {
  const tags = new Set();
  for (const match of String(text).matchAll(/#([A-Za-z0-9_]{1,50})/g)) {
    tags.add(match[1].toLowerCase());
  }
  return [...tags].slice(0, 15);
}

module.exports = {
  validatePassword,
  validateRegister,
  validateLogin,
  validateProfileUpdate,
  validatePostContent,
  validateComment,
  validateObjectId,
  validateSearchQuery,
  parsePagination,
  escapeRegex,
  extractHashtags,
};
