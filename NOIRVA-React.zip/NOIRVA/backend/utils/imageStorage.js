const crypto = require('crypto');
const fs = require('fs/promises');
const path = require('path');
const ApiError = require('./ApiError');

const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
const MAX_BYTES = 5 * 1024 * 1024;

// Checks real file signatures (magic bytes) instead of trusting the client MIME type.
function detectImageType(buf) {
  if (!buf || buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  const head6 = buf.subarray(0, 6).toString('ascii');
  if (head6 === 'GIF87a' || head6 === 'GIF89a') return 'gif';
  if (buf.subarray(0, 4).toString('ascii') === 'RIFF' && buf.subarray(8, 12).toString('ascii') === 'WEBP') return 'webp';
  return null;
}

async function saveImage(file) {
  if (!file) return null;
  if (file.size > MAX_BYTES) throw new ApiError(413, 'Image must be 5 MB or smaller');
  const ext = detectImageType(file.buffer);
  if (!ext) throw new ApiError(400, 'Unsupported or invalid image. Use JPG, PNG, GIF, or WEBP.');
  const name = `${crypto.randomUUID()}.${ext}`;
  await fs.mkdir(UPLOAD_DIR, { recursive: true });
  await fs.writeFile(path.join(UPLOAD_DIR, name), file.buffer, { flag: 'wx' });
  return `/uploads/${name}`;
}

// Only deletes names that match our generated pattern, which blocks path traversal.
async function deleteImage(urlPath) {
  if (!urlPath || !urlPath.startsWith('/uploads/')) return;
  const name = path.basename(urlPath);
  if (!/^[a-f0-9-]{36}\.(jpg|png|gif|webp)$/.test(name)) return;
  await fs.unlink(path.join(UPLOAD_DIR, name)).catch(() => {});
}

module.exports = { UPLOAD_DIR, MAX_BYTES, detectImageType, saveImage, deleteImage };
