const bcrypt = require('bcrypt');

const ROUNDS = Number(process.env.BCRYPT_ROUNDS) || 12;

const hashPassword = (plain) => bcrypt.hash(plain, ROUNDS);
const verifyPassword = (plain, hash) => bcrypt.compare(String(plain ?? ''), hash);

module.exports = { hashPassword, verifyPassword, ROUNDS };
