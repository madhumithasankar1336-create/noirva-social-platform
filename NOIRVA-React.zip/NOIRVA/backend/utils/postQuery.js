const Post = require('../models/Post');
const User = require('../models/User');
const Like = require('../models/Like');
const { serializePost } = require('./serializers');

// Shared aggregation for feeds, profiles, search, and single-post views.
// Like and comment counts are computed live, so no denormalized counters can drift.
async function fetchPosts({ match = {}, sort = { createdAt: -1 }, skip = 0, limit = 10, viewerId = null, scoreBy = false }) {
  const pipeline = [
    { $match: match },
    { $lookup: { from: 'likes', localField: '_id', foreignField: 'post', as: '_likes' } },
    { $lookup: { from: 'comments', localField: '_id', foreignField: 'post', as: '_comments' } },
    { $addFields: { likeCount: { $size: '$_likes' }, commentCount: { $size: '$_comments' } } },
    { $project: { _likes: 0, _comments: 0 } },
  ];
  if (scoreBy) {
    pipeline.push({ $addFields: { score: { $add: [{ $multiply: ['$likeCount', 2] }, '$commentCount'] } } });
  }
  pipeline.push({ $sort: sort }, { $skip: skip }, { $limit: limit + 1 });

  const rows = await Post.aggregate(pipeline);
  const hasMore = rows.length > limit;
  const items = rows.slice(0, limit);

  await User.populate(items, { path: 'author', select: 'name username profilePicture' });

  if (viewerId && items.length) {
    const likedRows = await Like.find({ user: viewerId, post: { $in: items.map((p) => p._id) } })
      .select('post')
      .lean();
    const liked = new Set(likedRows.map((l) => String(l.post)));
    items.forEach((p) => {
      p.likedByMe = liked.has(String(p._id));
    });
  }

  return { posts: items.map((p) => serializePost(p, viewerId)), hasMore };
}

module.exports = { fetchPosts };
