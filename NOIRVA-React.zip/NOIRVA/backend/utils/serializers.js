function publicUser(u) {
  if (!u) return null;
  return {
    id: String(u._id),
    name: u.name,
    username: u.username,
    profilePicture: u.profilePicture || '',
    coverImage: u.coverImage || '',
    bio: u.bio || '',
    location: u.location || '',
    website: u.website || '',
    createdAt: u.createdAt,
  };
}

function miniUser(u) {
  if (!u || !u.username) return null;
  return {
    id: String(u._id),
    name: u.name,
    username: u.username,
    profilePicture: u.profilePicture || '',
  };
}

function serializePost(p, viewerId) {
  const author = miniUser(p.author);
  return {
    id: String(p._id),
    content: p.content || '',
    imageUrl: p.imageUrl || '',
    hashtags: p.hashtags || [],
    createdAt: p.createdAt,
    updatedAt: p.updatedAt,
    author,
    likeCount: p.likeCount || 0,
    commentCount: p.commentCount || 0,
    likedByMe: Boolean(p.likedByMe),
    isOwner: Boolean(viewerId && author && author.id === String(viewerId)),
  };
}

function serializeComment(c, viewerId) {
  const author = miniUser(c.author);
  return {
    id: String(c._id),
    content: c.content,
    createdAt: c.createdAt,
    updatedAt: c.updatedAt,
    author,
    isOwner: Boolean(viewerId && author && author.id === String(viewerId)),
  };
}

function serializeNotification(n) {
  return {
    id: String(n._id),
    type: n.type,
    read: Boolean(n.read),
    createdAt: n.createdAt,
    sender: miniUser(n.sender),
    post: n.post && n.post._id
      ? { id: String(n.post._id), snippet: (n.post.content || '').slice(0, 90) }
      : null,
  };
}

module.exports = { publicUser, miniUser, serializePost, serializeComment, serializeNotification };
