const Notification = require('../models/Notification');

// Never notifies users about their own actions. Failures are logged and never break the main request.
async function notify({ recipient, sender, type, post = null }) {
  if (!recipient || !sender || String(recipient) === String(sender)) return null;
  try {
    return await Notification.create({ recipient, sender, type, post });
  } catch (err) {
    console.error('Notification failed:', err.message);
    return null;
  }
}

async function removePostNotifications(postId) {
  await Notification.deleteMany({ post: postId });
}

module.exports = { notify, removePostNotifications };
