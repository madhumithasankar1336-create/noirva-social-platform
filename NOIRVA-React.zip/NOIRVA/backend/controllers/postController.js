const mongoose = require('mongoose');
const Post = require('../models/Post');
const Follow = require('../models/Follow');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { fetchPosts } = require('../utils/postQuery');
const { parsePagination, validateObjectId, validatePostContent, extractHashtags } = require('../utils/validators');
const { saveImage, deleteImage } = require('../utils/imageStorage');
const { removePostNotifications } = require('../services/notificationService');
const Like = require('../models/Like');
const Comment = require('../models/Comment');

const DAY_MS = 24 * 60 * 60 * 1000;
const TABS = ['for-you', 'following', 'latest', 'popular'];

// Ranking strategies (documented in README):
// - for-you: posts from the last 30 days ranked by score = 2 * likes + comments, then recency.
// - popular: all posts ranked by the same score.
// - following: posts by the viewer and the accounts they follow, newest first.
// - latest: all posts, newest first.
async function feedHandler(req, res, tab) {
  if (!TABS.includes(tab)) throw new ApiError(400, 'Unknown feed tab');
  const { page, limit } = parsePagination(req.query, { defaultLimit: 10, maxLimit: 20 });

  let match = {};
  let sort = { createdAt: -1 };
  let scoreBy = false;

  if (tab === 'following') {
    if (!req.user) throw new ApiError(401, 'Please log in to view your following feed');
    const ids = await Follow.find({ follower: req.user._id }).distinct('following');
    match = { author: { $in: [...ids, req.user._id] } };
  } else if (tab === 'for-you') {
    match = { createdAt: { $gte: new Date(Date.now() - 30 * DAY_MS) } };
    sort = { score: -1, createdAt: -1 };
    scoreBy = true;
  } else if (tab === 'popular') {
    sort = { score: -1, createdAt: -1 };
    scoreBy = true;
  }

  if (req.query.media === '1') match = { ...match, imageUrl: { $ne: '' } };

  const result = await fetchPosts({
    match,
    sort,
    skip: (page - 1) * limit,
    limit,
    viewerId: req.user?._id,
    scoreBy,
  });
  res.json({ success: true, tab, page, ...result });
}

const getFeed = asyncHandler((req, res) => feedHandler(req, res, String(req.query.tab || 'for-you')));
const getFollowingFeed = asyncHandler((req, res) => feedHandler(req, res, 'following'));

const getPost = asyncHandler(async (req, res) => {
  const id = validateObjectId(req.params.id, 'post');
  const { posts } = await fetchPosts({ match: { _id: new mongoose.Types.ObjectId(id) }, limit: 1, viewerId: req.user?._id });
  if (!posts.length) throw new ApiError(404, 'Post not found');
  res.json({ success: true, post: posts[0] });
});

const createPost = asyncHandler(async (req, res) => {
  const content = validatePostContent(req.body?.content);
  if (!content && !req.file) {
    throw new ApiError(400, 'Write something or attach an image to publish', { content: 'Post cannot be empty' });
  }
  const imageUrl = (await saveImage(req.file)) || '';
  const post = await Post.create({
    author: req.user._id,
    content,
    imageUrl,
    hashtags: extractHashtags(content),
  });
  const { posts } = await fetchPosts({ match: { _id: post._id }, limit: 1, viewerId: req.user._id });
  res.status(201).json({ success: true, message: 'Post published', post: posts[0] });
});

async function loadOwnedPost(req) {
  const id = validateObjectId(req.params.id, 'post');
  const post = await Post.findById(id);
  if (!post) throw new ApiError(404, 'Post not found');
  if (!post.author.equals(req.user._id)) throw new ApiError(403, 'You can only modify your own posts');
  return post;
}

const updatePost = asyncHandler(async (req, res) => {
  const post = await loadOwnedPost(req);

  if (req.body?.content !== undefined) post.content = validatePostContent(req.body.content);

  if (req.file) {
    const newImage = await saveImage(req.file);
    await deleteImage(post.imageUrl);
    post.imageUrl = newImage;
  } else if (req.body?.removeImage === 'true') {
    await deleteImage(post.imageUrl);
    post.imageUrl = '';
  }

  if (!post.content && !post.imageUrl) {
    throw new ApiError(400, 'A post needs text or an image', { content: 'Post cannot be empty' });
  }

  post.hashtags = extractHashtags(post.content);
  await post.save();

  const { posts } = await fetchPosts({ match: { _id: post._id }, limit: 1, viewerId: req.user._id });
  res.json({ success: true, message: 'Post updated', post: posts[0] });
});

const deletePost = asyncHandler(async (req, res) => {
  const post = await loadOwnedPost(req);
  await Promise.all([
    Like.deleteMany({ post: post._id }),
    Comment.deleteMany({ post: post._id }),
    removePostNotifications(post._id),
    deleteImage(post.imageUrl),
  ]);
  await post.deleteOne();
  res.json({ success: true, message: 'Post deleted' });
});

module.exports = {
  getFeed,
  getFollowingFeed,
  getPost,
  createPost,
  updatePost,
  deletePost,
};
