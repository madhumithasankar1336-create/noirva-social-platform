const User = require('../models/User');
const Post = require('../models/Post');
const Comment = require('../models/Comment');
const Like = require('../models/Like');
const Follow = require('../models/Follow');
const Notification = require('../models/Notification');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { validateProfileUpdate, parsePagination, validateObjectId } = require('../utils/validators');
const { saveImage, deleteImage } = require('../utils/imageStorage');
const { publicUser, miniUser } = require('../utils/serializers');
const { fetchPosts } = require('../utils/postQuery');
const { verifyPassword } = require('../utils/passwords');
const { clearAuthCookie } = require('../utils/auth');

async function findByUsername(username) {
  const user = await User.findOne({ username: String(username || '').toLowerCase() });
  if (!user) throw new ApiError(404, 'User not found');
  return user;
}

const getStats = asyncHandler(async (req, res) => {
  const [users, posts, comments, likes] = await Promise.all([
    User.countDocuments(),
    Post.countDocuments(),
    Comment.countDocuments(),
    Like.countDocuments(),
  ]);
  res.json({ success: true, stats: { users, posts, comments, likes } });
});

const getSuggestions = asyncHandler(async (req, res) => {
  const following = await Follow.find({ follower: req.user._id }).distinct('following');
  const excludeIds = [req.user._id, ...following];
  const users = await User.aggregate([
    { $match: { _id: { $nin: excludeIds } } },
    { $sample: { size: 6 } },
    { $project: { name: 1, username: 1, profilePicture: 1, bio: 1 } },
  ]);
  res.json({
    success: true,
    users: users.map((u) => ({
      id: String(u._id),
      name: u.name,
      username: u.username,
      profilePicture: u.profilePicture || '',
      bio: u.bio || '',
    })),
  });
});

const getProfile = asyncHandler(async (req, res) => {
  const user = await findByUsername(req.params.username);
  const [posts, followers, following, follow] = await Promise.all([
    Post.countDocuments({ author: user._id }),
    Follow.countDocuments({ following: user._id }),
    Follow.countDocuments({ follower: user._id }),
    req.user ? Follow.exists({ follower: req.user._id, following: user._id }) : null,
  ]);
  res.json({
    success: true,
    user: {
      ...publicUser(user),
      stats: { posts, followers, following },
      isSelf: Boolean(req.user && String(req.user._id) === String(user._id)),
      isFollowing: Boolean(follow),
    },
  });
});

const updateMe = asyncHandler(async (req, res) => {
  const updates = validateProfileUpdate(req.body);
  const user = await User.findById(req.user._id);

  const profileFile = req.files?.profilePicture?.[0];
  const coverFile = req.files?.coverImage?.[0];

  if (profileFile) {
    const newPath = await saveImage(profileFile);
    await deleteImage(user.profilePicture);
    user.profilePicture = newPath;
  }
  if (coverFile) {
    const newPath = await saveImage(coverFile);
    await deleteImage(user.coverImage);
    user.coverImage = newPath;
  }

  Object.assign(user, updates);
  await user.save();
  res.json({ success: true, message: 'Profile updated', user: publicUser(user) });
});

// Documented deletion policy: removes the account's posts (and their likes, comments,
// notifications and images), the user's own likes, comments, follows, and notifications.
const deleteAccount = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).select('+passwordHash');
  const ok = await verifyPassword(req.body?.password, user.passwordHash);
  if (!ok) throw new ApiError(401, 'Password is incorrect. Your account was not deleted.');

  const posts = await Post.find({ author: user._id }).select('imageUrl');
  const postIds = posts.map((p) => p._id);

  await Promise.all([
    Like.deleteMany({ $or: [{ user: user._id }, { post: { $in: postIds } }] }),
    Comment.deleteMany({ $or: [{ author: user._id }, { post: { $in: postIds } }] }),
    Follow.deleteMany({ $or: [{ follower: user._id }, { following: user._id }] }),
    Notification.deleteMany({ $or: [{ recipient: user._id }, { sender: user._id }, { post: { $in: postIds } }] }),
    Post.deleteMany({ author: user._id }),
  ]);

  await Promise.all([
    ...posts.map((p) => deleteImage(p.imageUrl)),
    deleteImage(user.profilePicture),
    deleteImage(user.coverImage),
  ]);
  await User.deleteOne({ _id: user._id });

  clearAuthCookie(res);
  res.json({ success: true, message: 'Your account and its content have been permanently deleted' });
});

const getUserPosts = asyncHandler(async (req, res) => {
  const user = await findByUsername(req.params.username);
  const { page, limit } = parsePagination(req.query, { defaultLimit: 10, maxLimit: 20 });
  const result = await fetchPosts({
    match: { author: user._id },
    sort: { createdAt: -1 },
    skip: (page - 1) * limit,
    limit,
    viewerId: req.user?._id,
  });
  res.json({ success: true, page, ...result });
});

function listHandler(direction) {
  return asyncHandler(async (req, res) => {
    const user = await findByUsername(req.params.username);
    const { page, limit } = parsePagination(req.query, { defaultLimit: 20, maxLimit: 50 });
    const filter = direction === 'followers' ? { following: user._id } : { follower: user._id };
    const populateField = direction === 'followers' ? 'follower' : 'following';

    const rows = await Follow.find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit + 1)
      .populate(populateField, 'name username profilePicture')
      .lean();

    const hasMore = rows.length > limit;
    const users = rows
      .slice(0, limit)
      .map((r) => miniUser(r[populateField]))
      .filter(Boolean);
    res.json({ success: true, users, hasMore });
  });
}

module.exports = {
  getStats,
  getSuggestions,
  getProfile,
  updateMe,
  deleteAccount,
  getUserPosts,
  getFollowers: listHandler('followers'),
  getFollowing: listHandler('following'),
};
