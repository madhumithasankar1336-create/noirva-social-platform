const Comment = require('../models/Comment');
const Post = require('../models/Post');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { parsePagination, validateObjectId, validateComment } = require('../utils/validators');
const { serializeComment } = require('../utils/serializers');
const { notify } = require('../services/notificationService');

const getComments = asyncHandler(async (req, res) => {
  const postId = validateObjectId(req.params.id, 'post');
  if (!(await Post.exists({ _id: postId }))) throw new ApiError(404, 'Post not found');

  const { page, limit } = parsePagination(req.query, { defaultLimit: 20, maxLimit: 50 });
  const rows = await Comment.find({ post: postId })
    .sort({ createdAt: 1 })
    .skip((page - 1) * limit)
    .limit(limit + 1)
    .populate('author', 'name username profilePicture')
    .lean();

  const hasMore = rows.length > limit;
  res.json({
    success: true,
    comments: rows.slice(0, limit).map((c) => serializeComment(c, req.user?._id)),
    hasMore,
  });
});

const createComment = asyncHandler(async (req, res) => {
  const postId = validateObjectId(req.params.id, 'post');
  const content = validateComment(req.body?.content);

  const post = await Post.findById(postId).select('author');
  if (!post) throw new ApiError(404, 'Post not found');

  const comment = await Comment.create({ post: postId, author: req.user._id, content });
  await notify({ recipient: post.author, sender: req.user._id, type: 'comment', post: postId });

  await comment.populate('author', 'name username profilePicture');
  const commentCount = await Comment.countDocuments({ post: postId });
  res.status(201).json({ success: true, comment: serializeComment(comment, req.user._id), commentCount });
});

async function loadOwnedComment(req) {
  const id = validateObjectId(req.params.id, 'comment');
  const comment = await Comment.findById(id);
  if (!comment) throw new ApiError(404, 'Comment not found');
  if (!comment.author.equals(req.user._id)) throw new ApiError(403, 'You can only modify your own comments');
  return comment;
}

const updateComment = asyncHandler(async (req, res) => {
  const comment = await loadOwnedComment(req);
  comment.content = validateComment(req.body?.content);
  await comment.save();
  await comment.populate('author', 'name username profilePicture');
  res.json({ success: true, message: 'Comment updated', comment: serializeComment(comment, req.user._id) });
});

const deleteComment = asyncHandler(async (req, res) => {
  const comment = await loadOwnedComment(req);
  const postId = comment.post;
  await comment.deleteOne();
  const commentCount = await Comment.countDocuments({ post: postId });
  res.json({ success: true, message: 'Comment deleted', commentCount });
});

module.exports = { getComments, createComment, updateComment, deleteComment };
