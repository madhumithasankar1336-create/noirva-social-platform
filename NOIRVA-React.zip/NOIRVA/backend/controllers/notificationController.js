const Notification = require('../models/Notification');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { parsePagination, validateObjectId } = require('../utils/validators');
const { serializeNotification } = require('../utils/serializers');

const list = asyncHandler(async (req, res) => {
  const { page, limit } = parsePagination(req.query, { defaultLimit: 20, maxLimit: 50 });
  const rows = await Notification.find({ recipient: req.user._id })
    .sort({ createdAt: -1 })
    .skip((page - 1) * limit)
    .limit(limit + 1)
    .populate('sender', 'name username profilePicture')
    .populate('post', 'content imageUrl')
    .lean();

  const unreadCount = await Notification.countDocuments({ recipient: req.user._id, read: false });
  res.json({
    success: true,
    notifications: rows.slice(0, limit).map(serializeNotification),
    unreadCount,
    hasMore: rows.length > limit,
  });
});

// Ownership is enforced in the query itself, so other users receive 404 and cannot probe IDs.
const markRead = asyncHandler(async (req, res) => {
  const id = validateObjectId(req.params.id, 'notification');
  const updated = await Notification.findOneAndUpdate(
    { _id: id, recipient: req.user._id },
    { read: true },
    { new: true }
  );
  if (!updated) throw new ApiError(404, 'Notification not found');
  res.json({ success: true, notification: serializeNotification(updated) });
});

const markAllRead = asyncHandler(async (req, res) => {
  const result = await Notification.updateMany({ recipient: req.user._id, read: false }, { read: true });
  res.json({ success: true, updated: result.modifiedCount });
});

module.exports = { list, markRead, markAllRead };
