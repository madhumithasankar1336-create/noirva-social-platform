const bcrypt = require('bcrypt');
const User = require('../models/User');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { validateRegister, validateLogin, validatePassword } = require('../utils/validators');
const { setAuthCookie, clearAuthCookie } = require('../utils/auth');
const { saveImage, deleteImage } = require('../utils/imageStorage');
const { publicUser } = require('../utils/serializers');
const { hashPassword, verifyPassword, ROUNDS } = require('../utils/passwords');

// Used to equalize response time when the account does not exist (prevents user enumeration by timing).
const DUMMY_HASH = bcrypt.hashSync('noirva-timing-equalizer', ROUNDS);

const register = asyncHandler(async (req, res) => {
  const data = validateRegister(req.body);

  const existing = await User.findOne({ $or: [{ email: data.email }, { username: data.username }] }).select('email username');
  if (existing) {
    const errors = {};
    if (existing.email === data.email) errors.email = 'Email is already registered';
    if (existing.username === data.username) errors.username = 'Username is already taken';
    throw new ApiError(409, 'An account with these details already exists', errors);
  }

  const passwordHash = await hashPassword(data.password);
  const profilePicture = (await saveImage(req.file)) || '';

  let user;
  try {
    user = await User.create({ name: data.name, username: data.username, email: data.email, passwordHash, profilePicture });
  } catch (err) {
    await deleteImage(profilePicture);
    throw err;
  }

  setAuthCookie(res, user);
  res.status(201).json({ success: true, message: 'Welcome to NOIRVA', user: publicUser(user) });
});

const login = asyncHandler(async (req, res) => {
  const { identifier, password } = validateLogin(req.body);
  const query = identifier.includes('@') ? { email: identifier } : { username: identifier };

  const user = await User.findOne(query).select('+passwordHash');
  const ok = await verifyPassword(password, user ? user.passwordHash : DUMMY_HASH);
  if (!user || !ok) throw new ApiError(401, 'Invalid email/username or password');

  setAuthCookie(res, user);
  res.json({ success: true, message: 'Logged in', user: publicUser(user) });
});

const logout = (req, res) => {
  clearAuthCookie(res);
  res.json({ success: true, message: 'Logged out' });
};

const me = (req, res) => {
  res.json({ success: true, user: publicUser(req.user) });
};

const changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword, confirmPassword } = req.body || {};
  const user = await User.findById(req.user._id).select('+passwordHash');

  const currentOk = await verifyPassword(currentPassword, user.passwordHash);
  if (!currentOk) throw new ApiError(400, 'Validation failed', { currentPassword: 'Current password is incorrect' });

  const passwordError = validatePassword(newPassword);
  if (passwordError) throw new ApiError(400, 'Validation failed', { newPassword: passwordError });
  if (newPassword !== confirmPassword) throw new ApiError(400, 'Validation failed', { confirmPassword: 'Passwords do not match' });
  if (await verifyPassword(newPassword, user.passwordHash)) {
    throw new ApiError(400, 'Validation failed', { newPassword: 'New password must be different from the current one' });
  }

  user.passwordHash = await hashPassword(newPassword);
  user.tokenVersion += 1; // invalidates all previously issued sessions
  await user.save();

  setAuthCookie(res, user); // keep the current session alive
  res.json({ success: true, message: 'Password updated. Other sessions have been signed out.' });
});

module.exports = { register, login, logout, me, changePassword };
