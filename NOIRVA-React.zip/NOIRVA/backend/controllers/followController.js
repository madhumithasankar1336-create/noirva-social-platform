const User = require('../models/User');
const Follow = require('../models/Follow');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { validateObjectId } = require('../utils/validators');
const { notify } = require('../services/notificationService');

const follow = asyncHandler(async (req, res) => {
  const targetId = validateObjectId(req.params.id, 'user');
  if (targetId === String(req.user._id)) throw new ApiError(400, 'You cannot follow yourself');

  const target = await User.exists({ _id: targetId });
  if (!target) throw new ApiError(404, 'User not found');

  let created = true;
  try {
    await Follow.create({ follower: req.user._id, following: targetId });
  } catch (err) {
    if (err.code !== 11000) throw err;
    created = false;
  }

  if (created) await notify({ recipient: targetId, sender: req.user._id, type: 'follow' });

  const followers = await Follow.countDocuments({ following: targetId });
  res.status(created ? 201 : 200).json({ success: true, following: true, followers });
});

const unfollow = asyncHandler(async (req, res) => {
  const targetId = validateObjectId(req.params.id, 'user');
  await Follow.deleteOne({ follower: req.user._id, following: targetId });
  const followers = await Follow.countDocuments({ following: targetId });
  res.json({ success: true, following: false, followers });
});

module.exports = { follow, unfollow };
