const Post = require('../models/Post');
const Like = require('../models/Like');
const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const { validateObjectId } = require('../utils/validators');
const { notify } = require('../services/notificationService');

// Idempotent: the unique index on (post, user) guarantees one like per user per post,
// even under concurrent requests. A duplicate like returns 200 with the current state.
const like = asyncHandler(async (req, res) => {
  const postId = validateObjectId(req.params.id, 'post');
  const post = await Post.findById(postId).select('author');
  if (!post) throw new ApiError(404, 'Post not found');

  let created = true;
  try {
    await Like.create({ post: postId, user: req.user._id });
  } catch (err) {
    if (err.code !== 11000) throw err;
    created = false;
  }

  if (created) await notify({ recipient: post.author, sender: req.user._id, type: 'like', post: postId });

  const likeCount = await Like.countDocuments({ post: postId });
  res.status(created ? 201 : 200).json({ success: true, liked: true, likeCount });
});

const unlike = asyncHandler(async (req, res) => {
  const postId = validateObjectId(req.params.id, 'post');
  if (!(await Post.exists({ _id: postId }))) throw new ApiError(404, 'Post not found');
  await Like.deleteOne({ post: postId, user: req.user._id });
  const likeCount = await Like.countDocuments({ post: postId });
  res.json({ success: true, liked: false, likeCount });
});

module.exports = { like, unlike };
