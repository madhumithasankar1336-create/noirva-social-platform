const Post = require('../models/Post');
const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');
const { fetchPosts } = require('../utils/postQuery');
const { validateSearchQuery, escapeRegex, parsePagination } = require('../utils/validators');
const { miniUser } = require('../utils/serializers');

const DAY_MS = 24 * 60 * 60 * 1000;

const searchUsers = asyncHandler(async (req, res) => {
  const q = validateSearchQuery(req.query.q);
  const rx = new RegExp(escapeRegex(q), 'i');
  const users = await User.find({ $or: [{ name: rx }, { username: rx }] })
    .select('name username profilePicture')
    .limit(20)
    .lean();
  res.json({ success: true, users: users.map((u) => miniUser(u)) });
});

const searchPosts = asyncHandler(async (req, res) => {
  const q = validateSearchQuery(req.query.q);
  const { page, limit } = parsePagination(req.query, { defaultLimit: 10, maxLimit: 20 });
  const tag = q.replace(/^#/, '').toLowerCase();
  const rx = new RegExp(escapeRegex(q), 'i');
  const result = await fetchPosts({
    match: { $or: [{ content: rx }, { hashtags: tag }] },
    sort: { createdAt: -1 },
    skip: (page - 1) * limit,
    limit,
    viewerId: req.user?._id,
  });
  res.json({ success: true, page, ...result });
});

const searchHashtags = asyncHandler(async (req, res) => {
  const q = validateSearchQuery(req.query.q).replace(/^#/, '').toLowerCase();
  const prefix = escapeRegex(q);
  if (!prefix) return res.json({ success: true, tags: [] });
  const tags = await Post.aggregate([
    { $unwind: '$hashtags' },
    { $match: { hashtags: { $regex: `^${prefix}` } } },
    { $group: { _id: '$hashtags', count: { $sum: 1 } } },
    { $sort: { count: -1, _id: 1 } },
    { $limit: 15 },
  ]);
  res.json({ success: true, tags: tags.map((t) => ({ tag: t._id, count: t.count })) });
});

// Real counts from stored posts over the last 7 days. No fabricated metrics.
const getTrending = asyncHandler(async (req, res) => {
  const since = new Date(Date.now() - 7 * DAY_MS);
  const tags = await Post.aggregate([
    { $match: { createdAt: { $gte: since } } },
    { $unwind: '$hashtags' },
    { $group: { _id: '$hashtags', count: { $sum: 1 } } },
    { $sort: { count: -1, _id: 1 } },
    { $limit: 10 },
  ]);
  res.json({ success: true, windowDays: 7, tags: tags.map((t) => ({ tag: t._id, count: t.count })) });
});

module.exports = { searchUsers, searchPosts, searchHashtags, getTrending };
