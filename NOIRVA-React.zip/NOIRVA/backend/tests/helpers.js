const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../app');

const CSRF = { 'X-Requested-With': 'NOIRVA' };
let seq = 0;

async function clearDatabase() {
  const collections = await mongoose.connection.db.collections();
  await Promise.all(collections.map((c) => c.deleteMany({})));
}

async function registerUser(overrides = {}) {
  seq += 1;
  const username = overrides.username || `user${seq}x${Math.floor(Math.random() * 1000)}`;
  const body = {
    name: 'Test User',
    username,
    email: `${username}@example.com`,
    password: 'Password123',
    confirmPassword: 'Password123',
    ...overrides,
  };
  const res = await request(app).post('/api/auth/register').set(CSRF).send(body);
  if (res.status !== 201) throw new Error(`register failed: ${res.status} ${JSON.stringify(res.body)}`);
  return { user: res.body.user, cookie: res.headers['set-cookie'][0].split(';')[0], body };
}

module.exports = { app, request, CSRF, clearDatabase, registerUser };
