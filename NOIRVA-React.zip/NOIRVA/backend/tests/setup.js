const crypto = require('crypto');

// Test-only defaults. Real secrets are never stored in source code: the JWT secret is random per run.
process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(48).toString('hex');
process.env.BCRYPT_ROUNDS = process.env.BCRYPT_ROUNDS || '4';

const mongoose = require('mongoose');

const TEST_URI = process.env.MONGODB_TEST_URI;

beforeAll(async () => {
  if (!TEST_URI || !/test/i.test(TEST_URI)) {
    throw new Error('Set MONGODB_TEST_URI to a dedicated test database (its name must contain "test").');
  }
  await mongoose.connect(TEST_URI);
  await mongoose.connection.db.dropDatabase();
  // Build unique indexes so duplicate-prevention tests are meaningful.
  await Promise.all(Object.values(mongoose.models).map((m) => m.init()));
});

afterAll(async () => {
  if (mongoose.connection.readyState === 1) {
    await mongoose.connection.db.dropDatabase();
    await mongoose.disconnect();
  }
});
