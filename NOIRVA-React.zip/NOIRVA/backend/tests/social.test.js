const { request, CSRF, clearDatabase, registerUser } = require('./helpers');
const { app } = require('./helpers');

beforeEach(clearDatabase);

async function createPost(cookie, content = 'A post') {
  const res = await request(app).post('/api/posts').set(CSRF).set('Cookie', cookie).send({ content });
  return res.body.post;
}

describe('Comments', () => {
  test('rejects empty comments and creates valid ones', async () => {
    const author = await registerUser();
    const commenter = await registerUser();
    const post = await createPost(author.cookie);

    const empty = await request(app)
      .post(`/api/posts/${post.id}/comments`)
      .set(CSRF)
      .set('Cookie', commenter.cookie)
      .send({ content: '  ' });
    expect(empty.status).toBe(400);

    const ok = await request(app)
      .post(`/api/posts/${post.id}/comments`)
      .set(CSRF)
      .set('Cookie', commenter.cookie)
      .send({ content: 'Lovely!' });
    expect(ok.status).toBe(201);
    expect(ok.body.commentCount).toBe(1);
  });

  test('users cannot edit or delete other users comments', async () => {
    const author = await registerUser();
    const commenter = await registerUser();
    const intruder = await registerUser();
    const post = await createPost(author.cookie);
    const c = await request(app)
      .post(`/api/posts/${post.id}/comments`)
      .set(CSRF)
      .set('Cookie', commenter.cookie)
      .send({ content: 'Original comment' });
    const commentId = c.body.comment.id;

    const edit = await request(app).put(`/api/comments/${commentId}`).set(CSRF).set('Cookie', intruder.cookie).send({ content: 'Nope' });
    expect(edit.status).toBe(403);

    const del = await request(app).delete(`/api/comments/${commentId}`).set(CSRF).set('Cookie', intruder.cookie);
    expect(del.status).toBe(403);

    const ownEdit = await request(app).put(`/api/comments/${commentId}`).set(CSRF).set('Cookie', commenter.cookie).send({ content: 'Edited' });
    expect(ownEdit.status).toBe(200);
    expect(ownEdit.body.comment.content).toBe('Edited');
  });
});

describe('Likes', () => {
  test('like, duplicate like, and unlike keep counts accurate', async () => {
    const author = await registerUser();
    const fan = await registerUser();
    const post = await createPost(author.cookie);

    const first = await request(app).post(`/api/posts/${post.id}/like`).set(CSRF).set('Cookie', fan.cookie);
    expect(first.status).toBe(201);
    expect(first.body.likeCount).toBe(1);

    const duplicate = await request(app).post(`/api/posts/${post.id}/like`).set(CSRF).set('Cookie', fan.cookie);
    expect(duplicate.status).toBe(200);
    expect(duplicate.body.likeCount).toBe(1);

    const removed = await request(app).delete(`/api/posts/${post.id}/like`).set(CSRF).set('Cookie', fan.cookie);
    expect(removed.body.likeCount).toBe(0);
  });

  test('authors receive a like notification, but not for their own likes', async () => {
    const author = await registerUser();
    const fan = await registerUser();
    const post = await createPost(author.cookie);

    await request(app).post(`/api/posts/${post.id}/like`).set(CSRF).set('Cookie', author.cookie);
    let list = await request(app).get('/api/notifications').set('Cookie', author.cookie);
    expect(list.body.notifications).toHaveLength(0);

    await request(app).post(`/api/posts/${post.id}/like`).set(CSRF).set('Cookie', fan.cookie);
    list = await request(app).get('/api/notifications').set('Cookie', author.cookie);
    expect(list.body.notifications).toHaveLength(1);
    expect(list.body.notifications[0].type).toBe('like');
    expect(list.body.unreadCount).toBe(1);
  });
});

describe('Follows', () => {
  test('prevents self-follow and duplicate follows; counts stay accurate', async () => {
    const a = await registerUser();
    const b = await registerUser();

    const self = await request(app).post(`/api/users/${a.user.id}/follow`).set(CSRF).set('Cookie', a.cookie);
    expect(self.status).toBe(400);

    const first = await request(app).post(`/api/users/${b.user.id}/follow`).set(CSRF).set('Cookie', a.cookie);
    expect(first.status).toBe(201);
    expect(first.body.followers).toBe(1);

    const dup = await request(app).post(`/api/users/${b.user.id}/follow`).set(CSRF).set('Cookie', a.cookie);
    expect(dup.status).toBe(200);
    expect(dup.body.followers).toBe(1);

    const profile = await request(app).get(`/api/users/${b.user.username}`).set('Cookie', a.cookie);
    expect(profile.body.user.stats.followers).toBe(1);
    expect(profile.body.user.isFollowing).toBe(true);

    const unfollow = await request(app).delete(`/api/users/${b.user.id}/follow`).set(CSRF).set('Cookie', a.cookie);
    expect(unfollow.body.followers).toBe(0);
  });

  test('following feed shows only followed users and self', async () => {
    const a = await registerUser();
    const b = await registerUser();
    const c = await registerUser();
    await createPost(b.cookie, 'From followed user');
    await createPost(c.cookie, 'From stranger');
    await createPost(a.cookie, 'My own post');
    await request(app).post(`/api/users/${b.user.id}/follow`).set(CSRF).set('Cookie', a.cookie);

    const res = await request(app).get('/api/posts?tab=following').set('Cookie', a.cookie);
    const contents = res.body.posts.map((p) => p.content);
    expect(contents).toEqual(expect.arrayContaining(['From followed user', 'My own post']));
    expect(contents).not.toContain('From stranger');
  });
});

describe('Notifications authorization', () => {
  test('a user cannot mark another user notification as read', async () => {
    const author = await registerUser();
    const fan = await registerUser();
    const intruder = await registerUser();
    const post = await createPost(author.cookie);
    await request(app).post(`/api/posts/${post.id}/like`).set(CSRF).set('Cookie', fan.cookie);

    const list = await request(app).get('/api/notifications').set('Cookie', author.cookie);
    const notifId = list.body.notifications[0].id;

    const forbidden = await request(app).patch(`/api/notifications/${notifId}/read`).set(CSRF).set('Cookie', intruder.cookie);
    expect(forbidden.status).toBe(404);

    const owner = await request(app).patch(`/api/notifications/${notifId}/read`).set(CSRF).set('Cookie', author.cookie);
    expect(owner.status).toBe(200);
    expect(owner.body.notification.read).toBe(true);
  });
});

describe('Profile permissions', () => {
  test('profile update modifies only the caller account, never another user', async () => {
    const owner = await registerUser();
    const other = await registerUser();
    const res = await request(app)
      .put('/api/users/me')
      .set(CSRF)
      .set('Cookie', other.cookie)
      .send({ bio: 'Changed by other' });
    expect(res.status).toBe(200);
    expect(res.body.user.id).toBe(other.user.id);

    const ownerView = await request(app).get(`/api/users/${owner.user.username}`);
    expect(ownerView.body.user.bio).toBe('');
  });

  test('non-http website values are rejected', async () => {
    const { cookie } = await registerUser();
    const res = await request(app)
      .put('/api/users/me')
      .set(CSRF)
      .set('Cookie', cookie)
      .send({ website: 'javascript:alert(1)' });
    expect(res.status).toBe(400);
    expect(res.body.errors.website).toBeDefined();
  });
});
