const { request, CSRF, clearDatabase, registerUser } = require('./helpers');
const { app } = require('./helpers');
const Post = require('../models/Post');

beforeEach(clearDatabase);

const PNG_1X1 = Buffer.from(
  '89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d4944415478da63f8cfc0f01f0005000201a5f6457f0000000049454e44ae426082',
  'hex'
);

describe('Post creation and validation', () => {
  test('rejects an empty post with no image', async () => {
    const { cookie } = await registerUser();
    const res = await request(app).post('/api/posts').set(CSRF).set('Cookie', cookie).send({ content: '   ' });
    expect(res.status).toBe(400);
  });

  test('creates a post and extracts hashtags', async () => {
    const { cookie } = await registerUser();
    const res = await request(app)
      .post('/api/posts')
      .set(CSRF)
      .set('Cookie', cookie)
      .send({ content: 'Hello #NoirVA and #design' });
    expect(res.status).toBe(201);
    expect(res.body.post.hashtags).toEqual(['noirva', 'design']);
    expect(res.body.post.isOwner).toBe(true);
  });

  test('requires authentication to create posts', async () => {
    const res = await request(app).post('/api/posts').set(CSRF).send({ content: 'anon' });
    expect(res.status).toBe(401);
  });

  test('accepts a real PNG upload and stores it under /uploads', async () => {
    const { cookie } = await registerUser();
    const res = await request(app)
      .post('/api/posts')
      .set(CSRF)
      .set('Cookie', cookie)
      .field('content', 'With an image')
      .attach('image', PNG_1X1, { filename: 'pixel.png', contentType: 'image/png' });
    expect(res.status).toBe(201);
    expect(res.body.post.imageUrl).toMatch(/^\/uploads\/[a-f0-9-]{36}\.png$/);
  });

  test('rejects files that claim to be images but are not', async () => {
    const { cookie } = await registerUser();
    const res = await request(app)
      .post('/api/posts')
      .set(CSRF)
      .set('Cookie', cookie)
      .field('content', 'Fake image')
      .attach('image', Buffer.from('this is definitely not a png file'), { filename: 'fake.png', contentType: 'image/png' });
    expect(res.status).toBe(400);
    expect(res.body.message).toMatch(/Unsupported or invalid image/);
  });

  test('rejects disallowed MIME types such as executables', async () => {
    const { cookie } = await registerUser();
    const res = await request(app)
      .post('/api/posts')
      .set(CSRF)
      .set('Cookie', cookie)
      .field('content', 'Malware')
      .attach('image', Buffer.from('MZ....'), { filename: 'evil.exe', contentType: 'application/x-msdownload' });
    expect(res.status).toBe(400);
  });
});

describe('Post permissions', () => {
  test('only the author can edit a post; others receive 403', async () => {
    const author = await registerUser();
    const other = await registerUser();
    const created = await request(app).post('/api/posts').set(CSRF).set('Cookie', author.cookie).send({ content: 'Original' });
    const postId = created.body.post.id;

    const forbidden = await request(app)
      .put(`/api/posts/${postId}`)
      .set(CSRF)
      .set('Cookie', other.cookie)
      .send({ content: 'Hacked' });
    expect(forbidden.status).toBe(403);

    const allowed = await request(app)
      .put(`/api/posts/${postId}`)
      .set(CSRF)
      .set('Cookie', author.cookie)
      .send({ content: 'Edited #update' });
    expect(allowed.status).toBe(200);
    expect(allowed.body.post.content).toBe('Edited #update');
    expect(allowed.body.post.hashtags).toEqual(['update']);
  });

  test('only the author can delete a post; deletion removes it', async () => {
    const author = await registerUser();
    const other = await registerUser();
    const created = await request(app).post('/api/posts').set(CSRF).set('Cookie', author.cookie).send({ content: 'Delete me' });
    const postId = created.body.post.id;

    const forbidden = await request(app).delete(`/api/posts/${postId}`).set(CSRF).set('Cookie', other.cookie);
    expect(forbidden.status).toBe(403);

    const allowed = await request(app).delete(`/api/posts/${postId}`).set(CSRF).set('Cookie', author.cookie);
    expect(allowed.status).toBe(200);
    expect(await Post.exists({ _id: postId })).toBeNull();
  });

  test('invalid post IDs return 400 and missing posts return 404', async () => {
    const { cookie } = await registerUser();
    const bad = await request(app).get('/api/posts/not-a-real-id');
    expect(bad.status).toBe(400);
    const missing = await request(app).get('/api/posts/507f1f77bcf86cd799439011');
    expect(missing.status).toBe(404);
  });
});
