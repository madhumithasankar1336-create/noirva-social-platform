const { app, request, CSRF, clearDatabase, registerUser } = require('./helpers');
const User = require('../models/User');

beforeEach(clearDatabase);

describe('Registration', () => {
  test('creates a user and stores a bcrypt hash, never the plain password', async () => {
    const { user, body } = await registerUser();
    const stored = await User.findById(user.id).select('+passwordHash');
    expect(stored.passwordHash).not.toBe(body.password);
    expect(stored.passwordHash).toMatch(/^\$2[aby]\$/);
    expect(user.passwordHash).toBeUndefined();
  });

  test('rejects duplicate email and username with 409 and field errors', async () => {
    const { body } = await registerUser({ username: 'first_user' });
    const res = await request(app)
      .post('/api/auth/register')
      .set(CSRF)
      .send({ ...body, username: 'second_user' });
    expect(res.status).toBe(409);
    expect(res.body.errors.email).toBeDefined();
  });

  test('rejects duplicate username', async () => {
    const { body } = await registerUser({ username: 'taken_name' });
    const res = await request(app)
      .post('/api/auth/register')
      .set(CSRF)
      .send({ ...body, email: 'different@example.com' });
    expect(res.status).toBe(409);
    expect(res.body.errors.username).toBeDefined();
  });

  test('rejects weak passwords and invalid emails', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .set(CSRF)
      .send({ name: 'A', username: 'weakpass', email: 'not-an-email', password: 'short', confirmPassword: 'short' });
    expect(res.status).toBe(400);
    expect(res.body.errors.password).toBeDefined();
    expect(res.body.errors.email).toBeDefined();
  });

  test('blocks requests missing the CSRF header', async () => {
    const res = await request(app).post('/api/auth/login').send({ identifier: 'x', password: 'y' });
    expect(res.status).toBe(403);
  });
});

describe('Login, session, and logout', () => {
  test('logs in with email or username and rejects wrong passwords', async () => {
    const { body } = await registerUser({ username: 'loginuser' });

    const byUsername = await request(app)
      .post('/api/auth/login')
      .set(CSRF)
      .send({ identifier: 'loginuser', password: body.password });
    expect(byUsername.status).toBe(200);
    expect(byUsername.headers['set-cookie'][0]).toMatch(/noirva_token=.*HttpOnly/i);

    const byEmail = await request(app)
      .post('/api/auth/login')
      .set(CSRF)
      .send({ identifier: body.email, password: body.password });
    expect(byEmail.status).toBe(200);

    const wrong = await request(app)
      .post('/api/auth/login')
      .set(CSRF)
      .send({ identifier: 'loginuser', password: 'WrongPass1' });
    expect(wrong.status).toBe(401);
    expect(wrong.body.message).toBe('Invalid email/username or password');
  });

  test('/me requires a valid session and never returns password data', async () => {
    const { cookie } = await registerUser();
    const anonymous = await request(app).get('/api/auth/me');
    expect(anonymous.status).toBe(401);

    const authed = await request(app).get('/api/auth/me').set('Cookie', cookie);
    expect(authed.status).toBe(200);
    expect(authed.body.user.passwordHash).toBeUndefined();
  });

  test('rejects tampered tokens', async () => {
    const res = await request(app).get('/api/auth/me').set('Cookie', 'noirva_token=garbage.token.value');
    expect(res.status).toBe(401);
  });

  test('logout clears the auth cookie', async () => {
    const { cookie } = await registerUser();
    const res = await request(app).post('/api/auth/logout').set(CSRF).set('Cookie', cookie);
    expect(res.status).toBe(200);
    expect(res.headers['set-cookie'][0]).toMatch(/noirva_token=;/);
  });

  test('changing password signs out other sessions', async () => {
    const { cookie: oldCookie, body } = await registerUser();
    const res = await request(app)
      .post('/api/auth/change-password')
      .set(CSRF)
      .set('Cookie', oldCookie)
      .send({ currentPassword: body.password, newPassword: 'NewPassword9', confirmPassword: 'NewPassword9' });
    expect(res.status).toBe(200);

    const stale = await request(app).get('/api/auth/me').set('Cookie', oldCookie);
    expect(stale.status).toBe(401);

    const relogin = await request(app)
      .post('/api/auth/login')
      .set(CSRF)
      .send({ identifier: body.username, password: 'NewPassword9' });
    expect(relogin.status).toBe(200);
  });
});

