const multer = require('multer');
const ApiError = require('../utils/ApiError');
const { MAX_BYTES } = require('../utils/imageStorage');

const ALLOWED_MIME = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_BYTES, files: 2 },
  fileFilter(req, file, cb) {
    if (!ALLOWED_MIME.includes(file.mimetype)) {
      return cb(new ApiError(400, 'Unsupported image type. Use JPG, PNG, GIF, or WEBP.'));
    }
    cb(null, true);
  },
});

const uploadSingle = (field) => upload.single(field);
const uploadFields = (fields) => upload.fields(fields);

module.exports = { uploadSingle, uploadFields };
